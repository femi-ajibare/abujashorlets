import { Amenities } from "./components/Amenities";
import { Areas, Apartments } from "./components/Apartments";
import { BookingBar } from "./components/BookingBar";
import { FinalCta, Footer } from "./components/CtaBanner";
import { EditToolbar } from "./components/EditToolbar";
import { Faq } from "./components/Faq";
import { FloatingWhatsApp } from "./components/FloatingWhatsApp";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { HowItWorks } from "./components/HowItWorks";
import { Testimonials } from "./components/Testimonials";
import { ContentProvider } from "./content";
import { useReveal } from "./hooks/useReveal";

function Site() {
  useReveal();

  return (
    <>
      <Header />
      <main>
        <Hero />
        <BookingBar />
        <Apartments />
        <Amenities />
        <Areas />
        <HowItWorks />
        <Testimonials />
        <Faq />
        <FinalCta />
      </main>
      <Footer />
      <FloatingWhatsApp />
      <EditToolbar />
    </>
  );
}

export default function App() {
  return (
    <ContentProvider>
      <Site />
    </ContentProvider>
  );
}
