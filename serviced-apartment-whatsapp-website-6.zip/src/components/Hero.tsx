import { Editable, EditableNumber, useContent } from "../content";
import { APARTMENTS, LOCATIONS } from "../data";
import { WhatsAppButton } from "./WhatsAppButton";
import { ArrowIcon, CheckIcon, StarIcon, WhatsAppIcon } from "./icons";

const HERO_IMAGE =
  "https://images.pexels.com/photos/8135496/pexels-photo-8135496.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1600&h=1100";

const PROOF = ["No sign-up", "No hidden fees", "Free cancellation up to 48h"];

export function Hero() {
  const { brand, wa } = useContent();
  const lowest = Math.min(...APARTMENTS.map((a) => a.price));

  return (
    <section id="top" className="relative overflow-hidden bg-cream pt-[72px]">
      <div className="mx-auto max-w-[1240px] px-5 pt-14 pb-16 sm:px-8 sm:pt-20">
        <div className="grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:gap-16">
          {/* Copy */}
          <div className="max-w-2xl">
            <div className="reveal is-visible flex flex-wrap items-center gap-3">
              <span className="inline-flex items-center gap-2 rounded-sm bg-shell px-3 py-1.5 text-[12px] font-bold text-moss">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="absolute inline-flex h-full w-full rounded-full bg-whatsapp opacity-70 ping-soft" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-whatsapp" />
                </span>
                Concierge online now
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-sm bg-shell px-3 py-1.5 text-[12px] font-bold text-moss">
                <StarIcon className="h-3.5 w-3.5 text-bronze" />
                {brand.rating} · {brand.reviews} reviews
              </span>
            </div>

            {/* Signature lowercase headline */}
            <h1 className="reveal is-visible mt-6 text-[38px] leading-[1.1] font-bold tracking-[-0.02em] text-ink sm:text-[54px] lg:text-[62px]">
              <Editable k="hero.h1a" value="verified luxury shortlets" as="span" />
              <br />
              <Editable k="hero.h1b" value="in Abuja" as="span" />
            </h1>

            <p className="reveal is-visible mt-6 max-w-xl text-[16px] leading-[1.75] text-ink-soft sm:text-[17px]">
              <Editable
                k="hero.sub"
                value="Vetted & verified serviced apartments across Katampe, Wuse 2, Asokoro, Maitama, Mabushi, Jahi and Gwarinpa. 24/7 power, fast wifi, pools and gyms — booked in a single WhatsApp message."
                as="span"
                multiline
              />
            </p>

            <div className="reveal is-visible mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
              <WhatsAppButton
                size="lg"
                message={`Hi ${brand.name}! I found you on your website and I'd like to book an apartment. Here are my dates: `}
              >
                Book on WhatsApp
              </WhatsAppButton>
              <a
                href="#apartments"
                className="group inline-flex h-14 items-center justify-center gap-2 rounded-sm border border-line bg-white px-7 text-[15px] font-bold text-ink transition-all duration-300 hover:border-bronze hover:text-bronze"
              >
                View apartments
                <ArrowIcon className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
            </div>

            <ul className="reveal is-visible mt-7 flex flex-wrap items-center gap-x-6 gap-y-3">
              {PROOF.map((item, i) => (
                <li
                  key={i}
                  className="flex items-center gap-2 text-[13.5px] font-medium text-ink-soft"
                >
                  <span className="grid h-5 w-5 place-items-center rounded-full bg-bronze/15 text-bronze">
                    <CheckIcon className="h-3 w-3" />
                  </span>
                  <Editable k={`hero.proof.${i}`} value={item} />
                </li>
              ))}
            </ul>

            <div className="reveal is-visible mt-10 flex flex-wrap items-end gap-8 border-t border-line pt-7">
              {[
                { value: `${APARTMENTS.length}+`, label: "Apartments" },
                { value: `${LOCATIONS.length}`, label: "Prime areas" },
                { value: "10 min", label: "Avg. reply time" },
              ].map((s) => (
                <div key={s.label}>
                  <p className="text-3xl font-bold tracking-[-0.02em] text-ink">
                    {s.value}
                  </p>
                  <p className="mt-1 text-[12.5px] font-medium text-ink-soft">
                    {s.label}
                  </p>
                </div>
              ))}
              <p className="text-[13px] text-ink-soft">
                Stays from{" "}
                <span className="font-bold text-ink">
                  ₦
                  <EditableNumber
                    k="hero.fromPrice"
                    value={lowest}
                    format={(v) => v.toLocaleString("en-NG")}
                  />
                </span>{" "}
                / night
              </p>
            </div>
          </div>

          {/* Visual */}
          <div className="reveal is-visible relative">
            <div className="relative overflow-hidden rounded-lg shadow-lift ring-1 ring-black/5">
              <img
                src={HERO_IMAGE}
                alt="Sunlit open-plan living room in an Abuja Shortlets serviced apartment"
                className="h-[340px] w-full object-cover sm:h-[460px] lg:h-[540px]"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/45 via-transparent to-transparent" />

              <a
                href={wa(
                  `Hi ${brand.name}! I'd love to see more photos and availability for your apartments.`,
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="absolute right-4 bottom-4 left-4 flex items-center gap-3 rounded-lg bg-white/95 p-3 pr-4 shadow-lift backdrop-blur transition-transform duration-300 hover:-translate-y-1 sm:right-5 sm:left-5"
              >
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-sm bg-whatsapp text-white">
                  <WhatsAppIcon className="h-6 w-6" />
                </span>
                <span className="min-w-0">
                  <span className="block text-[13.5px] font-bold text-ink">
                    Message our concierge
                  </span>
                  <span className="block truncate text-[12px] text-ink-soft">
                    Photos, availability &amp; pricing — replied in minutes
                  </span>
                </span>
              </a>
            </div>

            {/* Floating rating card */}
            <div className="bob absolute -top-4 -left-4 hidden rounded-lg bg-white/95 p-4 shadow-lift ring-1 ring-line backdrop-blur sm:block lg:-left-10">
              <div className="flex items-center gap-1 text-bronze">
                {Array.from({ length: 5 }).map((_, i) => (
                  <StarIcon key={i} className="h-3.5 w-3.5" />
                ))}
              </div>
              <p className="mt-2 text-[12.5px] font-bold text-ink">
                Rated {brand.rating}/5
              </p>
              <p className="text-[11px] text-ink-soft">
                by {brand.reviews} verified guests
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
