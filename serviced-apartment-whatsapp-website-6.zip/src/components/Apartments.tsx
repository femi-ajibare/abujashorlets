import { useCallback, useMemo, useRef, useState } from "react";
import { Editable, EditableNumber, useContent } from "../content";
import { APARTMENTS, AREAS, LOCATIONS, byArea, type Apartment } from "../data";
import { cn } from "../utils/cn";
import {
  exportManifest,
  fileToDataUrl,
  useImageStore,
  type ImageStore,
} from "../hooks/useImageStore";
import { WhatsAppButton } from "./WhatsAppButton";
import { ArrowIcon, CheckIcon, ChevronIcon, WhatsAppIcon } from "./icons";

/* ------------------------------------------------------------------ */
/* Photo carousel — with edit / add / remove controls                  */
/* ------------------------------------------------------------------ */

function Carousel({
  images,
  alt,
  onReplace,
  onAdd,
  onRemove,
}: {
  images: string[];
  alt: string;
  onReplace: (index: number) => void;
  onAdd: () => void;
  onRemove: (index: number) => void;
}) {
  const [index, setIndex] = useState(0);
  const count = images.length;

  const go = useCallback(
    (dir: number) => setIndex((i) => (i + dir + count) % count),
    [count],
  );

  const stop = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const toolbarBtn =
    "grid h-8 w-8 place-items-center rounded-sm bg-white/95 text-ink shadow transition-all duration-200 hover:bg-white hover:text-bronze";

  return (
    <div className="group/carousel relative h-full w-full overflow-hidden">
      <div
        className="flex h-full w-full transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]"
        style={{ transform: `translateX(-${index * 100}%)` }}
      >
        {images.map((src, i) => (
          <img
            key={src + i}
            src={src}
            alt={`${alt} — photo ${i + 1} of ${count}`}
            loading="lazy"
            className="h-full w-full shrink-0 object-cover"
          />
        ))}
      </div>

      {/* Arrows */}
      {count > 1 && (
        <>
          <button
            type="button"
            onClick={(e) => {
              stop(e);
              go(-1);
            }}
            aria-label="Previous photo"
            className="absolute top-1/2 left-2 grid h-8 w-8 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-ink opacity-0 shadow transition-all duration-300 hover:bg-white group-hover/carousel:opacity-100"
          >
            <ChevronIcon className="h-4 w-4 rotate-90" />
          </button>
          <button
            type="button"
            onClick={(e) => {
              stop(e);
              go(1);
            }}
            aria-label="Next photo"
            className="absolute top-1/2 right-2 grid h-8 w-8 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-ink opacity-0 shadow transition-all duration-300 hover:bg-white group-hover/carousel:opacity-100"
          >
            <ChevronIcon className="h-4 w-4 -rotate-90" />
          </button>
        </>
      )}

      {/* Edit toolbar — always visible so photos can be swapped on any device */}
      <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5">
        <button
          type="button"
          onClick={(e) => {
            stop(e);
            onReplace(index);
          }}
          title="Replace this photo with one from your files"
          aria-label="Replace this photo"
          className={toolbarBtn}
        >
          <svg
            viewBox="0 0 24 24"
            className="h-4 w-4"
            fill="none"
            stroke="currentColor"
            strokeWidth={1.8}
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M12 20h9" />
            <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z" />
          </svg>
        </button>
        <button
          type="button"
          onClick={(e) => {
            stop(e);
            onAdd();
          }}
          title="Add another photo to this apartment"
          aria-label="Add a photo"
          className={toolbarBtn}
        >
          <svg
            viewBox="0 0 24 24"
            className="h-4 w-4"
            fill="none"
            stroke="currentColor"
            strokeWidth={2}
            strokeLinecap="round"
          >
            <path d="M12 5v14M5 12h14" />
          </svg>
        </button>
        {count > 1 && (
          <button
            type="button"
            onClick={(e) => {
              stop(e);
              onRemove(index);
              setIndex((i) => Math.max(0, Math.min(i, count - 2)));
            }}
            title="Remove this photo"
            aria-label="Remove this photo"
            className="grid h-8 w-8 place-items-center rounded-sm bg-white/95 text-ink shadow transition-all duration-200 hover:bg-white hover:text-red-600"
          >
            <svg
              viewBox="0 0 24 24"
              className="h-4 w-4"
              fill="none"
              stroke="currentColor"
              strokeWidth={1.8}
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" />
              <path d="M10 11v6M14 11v6" />
            </svg>
          </button>
        )}
      </div>

      {/* Photo counter */}
      <span className="absolute bottom-2.5 right-2.5 rounded-sm bg-ink/70 px-1.5 py-0.5 text-[10px] font-bold text-white">
        {index + 1} / {count}
      </span>

      {/* Dots */}
      {count > 1 && (
        <div className="absolute bottom-2.5 left-1/2 flex -translate-x-1/2 items-center gap-1.5">
          {images.map((src, i) => (
            <button
              key={src + i}
              type="button"
              onClick={(e) => {
                stop(e);
                setIndex(i);
              }}
              aria-label={`Go to photo ${i + 1}`}
              className={cn(
                "h-1.5 rounded-full transition-all duration-300",
                i === index ? "w-5 bg-white" : "w-1.5 bg-white/60 hover:bg-white/80",
              )}
            />
          ))}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Property card                                                       */
/* ------------------------------------------------------------------ */

function PropertyCard({
  apt,
  images,
  onReplace,
  onAdd,
  onRemove,
}: {
  apt: Apartment;
  images: string[];
  onReplace: (index: number) => void;
  onAdd: () => void;
  onRemove: (index: number) => void;
}) {
  const { brand } = useContent();
  const message = [
    `Hi ${brand.name}! I'm interested in this property:`,
    ``,
    `“${apt.short}” — ${apt.area}`,
    `₦${apt.price.toLocaleString("en-NG")} /night`,
    ``,
    `My dates: `,
    `Number of guests: `,
    ``,
    `Is it available, and what's the total for my stay?`,
  ].join("\n");

  return (
    <article className="reveal group flex flex-col overflow-hidden rounded-lg bg-white shadow-soft ring-1 ring-line transition-all duration-500 ease-out hover:-translate-y-1 hover:shadow-lift">
      <div className="relative h-56 w-full overflow-hidden bg-shell">
        <Carousel
          images={images}
          alt={`${apt.short} — ${apt.area}`}
          onReplace={onReplace}
          onAdd={onAdd}
          onRemove={onRemove}
        />

        <div className="pointer-events-none absolute top-3 left-3 flex flex-wrap gap-1.5">
          {apt.featured && (
            <span className="rounded-sm bg-bronze px-2 py-1 text-[10px] font-bold tracking-[0.12em] text-white uppercase">
              featured
            </span>
          )}
          <span className="rounded-sm bg-white/95 px-2 py-1 text-[10px] font-bold tracking-[0.06em] text-moss uppercase shadow-sm">
            {apt.verified}
          </span>
        </div>
      </div>

      <div className="flex flex-1 flex-col p-5">
        <p className="flex items-baseline gap-1">
          <span className="text-[22px] font-bold text-ink">
            ₦{" "}
            <EditableNumber
              k={`apt.${apt.id}.price`}
              value={apt.price}
              format={(v) => v.toLocaleString("en-NG")}
            />
          </span>
          <span className="text-[13px] font-normal text-ink-soft">/night</span>
        </p>

        <p className="mt-2 flex flex-wrap items-center gap-x-1 text-[13px] font-medium text-ink-soft">
          <EditableNumber k={`apt.${apt.id}.guests`} value={apt.guests} /> Guests{" "}
          <span className="text-line">·</span>{" "}
          <EditableNumber k={`apt.${apt.id}.beds`} value={apt.beds} />{" "}
          <Editable k={`apt.${apt.id}.bedWord`} value={apt.beds === 1 ? "Bedroom" : "Bedrooms"} />{" "}
          <span className="text-line">·</span>{" "}
          <EditableNumber k={`apt.${apt.id}.baths`} value={apt.baths} />{" "}
          <Editable k={`apt.${apt.id}.bathWord`} value={apt.baths === 1 ? "Bathroom" : "Bathrooms"} />
        </p>

        <h3 className="mt-3 line-clamp-2 text-[15px] leading-[1.45] font-bold text-ink transition-colors duration-300 group-hover:text-bronze">
          <Editable k={`apt.${apt.id}.name`} value={apt.name} multiline />
        </h3>

        <ul className="mt-3.5 flex flex-wrap gap-1.5">
          {apt.amenities.slice(0, 3).map((a, ai) => (
            <li
              key={ai}
              className="inline-flex items-center gap-1 rounded-sm bg-shell px-2 py-1 text-[11px] font-medium text-ink"
            >
              <CheckIcon className="h-2.5 w-2.5 text-bronze" />
              <Editable k={`apt.${apt.id}.amenity.${ai}`} value={a} />
            </li>
          ))}
          {apt.amenities.length > 3 && (
            <li className="inline-flex items-center rounded-sm bg-shell px-2 py-1 text-[11px] font-medium text-ink-soft">
              +{apt.amenities.length - 3} more
            </li>
          )}
        </ul>

        <p className="mt-3.5 line-clamp-2 flex-1 text-[13.5px] leading-relaxed text-ink-soft">
          <Editable k={`apt.${apt.id}.blurb`} value={apt.blurb} multiline />
        </p>

        <WhatsAppButton fullWidth className="mt-5" message={message}>
          Book on WhatsApp
        </WhatsAppButton>
      </div>
    </article>
  );
}

/* ------------------------------------------------------------------ */
/* Per-area section                                                    */
/* ------------------------------------------------------------------ */

/** Stable anchor id from an area name, e.g. "Wuse 2" → "wuse-2". */
export function areaSlug(area: string) {
  return area.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

function AreaSection({
  area,
  apartments,
  store,
  pickFile,
}: {
  area: string;
  apartments: Apartment[];
  store: ImageStore;
  pickFile: (apt: Apartment, index: number | null) => void;
}) {
  const { brand } = useContent();
  const from = Math.min(...apartments.map((a) => a.price));
  const slug = areaSlug(area);

  return (
    <section
      id={`area-${slug}`}
      className="scroll-mt-20 border-t border-line py-12 first:border-t-0 sm:py-16"
    >
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8">
        {/* Area header */}
        <div className="reveal flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="flex items-center gap-2.5 text-[11px] font-bold tracking-[0.22em] text-bronze uppercase">
              <span className="h-px w-7 bg-bronze" />
              <EditableNumber
                k={`area.${slug}.count`}
                value={apartments.length}
              />{" "}
              <Editable
                k={`area.${slug}.countWord`}
                value={apartments.length === 1 ? "apartment" : "apartments"}
              />
            </p>
            <h3 className="mt-3 text-[26px] leading-tight text-ink sm:text-[32px]">
              <Editable k={`area.${slug}.heading`} value={`Shortlets in ${area}`} />
            </h3>
            <p className="mt-2 text-[14.5px] text-ink-soft">
              From{" "}
              <span className="font-bold text-ink">
                ₦
                <EditableNumber
                  k={`area.${slug}.from`}
                  value={from}
                  format={(v) => v.toLocaleString("en-NG")}
                />
              </span>{" "}
              / night
            </p>
          </div>

          <a
            href={`https://wa.me/${brand.whatsappNumber}?text=${encodeURIComponent(
              `Hi ${brand.name}! Do you have anything available in ${area}?`,
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex h-12 shrink-0 items-center gap-2 rounded-sm border border-line bg-white px-5 text-[14px] font-bold text-ink transition-all duration-300 hover:border-bronze hover:text-bronze"
          >
            Ask about {area}
            <ArrowIcon className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
          </a>
        </div>

        {/* Column grid — grows automatically as listings are added */}
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {apartments.map((apt) => (
            <PropertyCard
              key={apt.id}
              apt={apt}
              images={store.imagesFor(apt.id, apt.images)}
              onReplace={(index) => pickFile(apt, index)}
              onAdd={() => pickFile(apt, null)}
              onRemove={(index) => store.removeImage(apt.id, index)}
            />
          ))}

          {/* Always-ready slot for the next listing in this area */}
          <a
            href={`https://wa.me/${brand.whatsappNumber}?text=${encodeURIComponent(
              `Hi ${brand.name}! I'd like to list a new apartment in ${area}. Here are the details and photos: `,
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="reveal group flex min-h-[380px] flex-col items-center justify-center gap-3 rounded-lg border-2 border-dashed border-line bg-white/60 p-6 text-center transition-all duration-300 hover:border-bronze hover:bg-white"
          >
            <span className="grid h-12 w-12 place-items-center rounded-full bg-shell text-bronze transition-colors duration-300 group-hover:bg-bronze group-hover:text-white">
              <svg
                viewBox="0 0 24 24"
                className="h-6 w-6"
                fill="none"
                stroke="currentColor"
                strokeWidth={1.8}
                strokeLinecap="round"
              >
                <path d="M12 5v14M5 12h14" />
              </svg>
            </span>
            <span className="text-[15px] font-bold text-ink">
              Add a listing in {area}
            </span>
            <span className="max-w-[220px] text-[13px] leading-relaxed text-ink-soft">
              Send us the photos and details on WhatsApp and it goes live in this
              column straight away.
            </span>
          </a>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Section                                                             */
/* ------------------------------------------------------------------ */

const BEDROOM_OPTIONS = [
  "Any bedrooms",
  "Studio / 1 bed",
  "2 bedrooms",
  "3 bedrooms",
  "4+ bedrooms",
];

export function Apartments() {
  const [beds, setBeds] = useState(BEDROOM_OPTIONS[0]);
  const [guests, setGuests] = useState("Any guests");
  const [sort, setSort] = useState("Featured");
  const [notice, setNotice] = useState<string | null>(null);

  const { brand } = useContent();
  const store = useImageStore();
  const fileInput = useRef<HTMLInputElement>(null);
  const pending = useRef<{ apt: Apartment; index: number | null } | null>(null);

  /** Opens the OS file picker for a replace (index) or add (null) action. */
  const pickFile = useCallback((apt: Apartment, index: number | null) => {
    pending.current = { apt, index };
    fileInput.current?.click();
  }, []);

  const onFileChosen = useCallback(
    async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      e.target.value = "";
      const job = pending.current;
      pending.current = null;
      if (!file || !job) return;

      try {
        const dataUrl = await fileToDataUrl(file);
        if (job.index === null) store.addImage(job.apt.id, dataUrl);
        else store.replaceImage(job.apt.id, job.index, dataUrl);
        setNotice(`Photo saved for ${job.apt.short}.`);
      } catch (err) {
        setNotice(err instanceof Error ? err.message : "Could not use that file.");
      }
      window.setTimeout(() => setNotice(null), 4000);
    },
    [store],
  );

  const groups = useMemo(() => {
    const all = byArea().map((g) => ({
      ...g,
      apartments: g.apartments.filter((a) => {
        if (beds !== BEDROOM_OPTIONS[0]) {
          if (beds === "Studio / 1 bed" && a.beds > 1) return false;
          if (beds === "2 bedrooms" && a.beds !== 2) return false;
          if (beds === "3 bedrooms" && a.beds !== 3) return false;
          if (beds === "4+ bedrooms" && a.beds < 4) return false;
        }
        if (guests !== "Any guests") {
          const n = parseInt(guests, 10);
          if (a.guests < n) return false;
        }
        return true;
      }),
    }));

    if (sort === "Price: low to high" || sort === "Price: high to low") {
      all.forEach((g) => {
        g.apartments = [...g.apartments].sort((a, b) =>
          sort === "Price: low to high" ? a.price - b.price : b.price - a.price,
        );
      });
    }

    return all.filter((g) => g.apartments.length > 0);
  }, [beds, guests, sort]);

  const totalShown = groups.reduce((n, g) => n + g.apartments.length, 0);
  const filtered =
    beds !== BEDROOM_OPTIONS[0] || guests !== "Any guests" || sort !== "Featured";

  const reset = () => {
    setBeds(BEDROOM_OPTIONS[0]);
    setGuests("Any guests");
    setSort("Featured");
  };

  const selectClass =
    "w-full cursor-pointer appearance-none rounded-sm border border-line bg-white px-3.5 py-3 text-[14px] font-medium text-ink transition-colors duration-300 hover:border-bronze focus:border-bronze focus:outline-none";

  return (
    <section id="apartments" className="scroll-mt-20 bg-cream">
      {/* Hidden file picker used by every edit button */}
      <input
        ref={fileInput}
        type="file"
        accept="image/*"
        onChange={onFileChosen}
        className="hidden"
        aria-hidden="true"
        tabIndex={-1}
      />

      {/* Intro */}
      <div className="mx-auto max-w-[1240px] px-5 pt-14 pb-6 sm:px-8 sm:pt-20">
        <div className="reveal max-w-2xl">
          <p className="flex items-center gap-2.5 text-[11px] font-bold tracking-[0.22em] text-bronze uppercase">
            <span className="h-px w-7 bg-bronze" />
            The collection
          </p>
          <h2 className="mt-4 text-[30px] leading-[1.15] text-ink sm:text-[38px]">
            <Editable
              k="section.collection.title"
              value="verified luxury shortlets in Abuja"
            />
          </h2>
          <p className="mt-4 text-[15px] leading-relaxed text-ink-soft">
            <Editable
              k="section.collection.sub"
              value="Browse by area below — every apartment has been personally inspected and vetted. Filter by size and guests, then book in one WhatsApp message."
              multiline
            />
          </p>
        </div>

        {/* Image manager */}
        <div className="reveal mt-6 flex flex-col gap-3 rounded-lg border border-line bg-white p-4 shadow-soft sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-sm bg-shell text-bronze">
              <svg
                viewBox="0 0 24 24"
                className="h-5 w-5"
                fill="none"
                stroke="currentColor"
                strokeWidth={1.7}
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <rect x="3" y="3" width="18" height="18" rx="2" />
                <circle cx="8.5" cy="8.5" r="1.5" />
                <path d="m21 15-4.5-4.5L6 21" />
              </svg>
            </span>
            <div>
              <p className="text-[14px] font-bold text-ink">
                {store.uploadedCount > 0
                  ? `${store.uploadedCount} photo${store.uploadedCount === 1 ? "" : "s"} uploaded across ${store.editedCount} apartment${store.editedCount === 1 ? "" : "s"}`
                  : "Use your own photos"}
              </p>
              <p className="mt-0.5 text-[13px] leading-relaxed text-ink-soft">
                Tap the <span className="font-bold text-ink">pencil</span> on any
                photo to swap in a file from your device,{" "}
                <span className="font-bold text-ink">+</span> to add more, or the{" "}
                <span className="font-bold text-ink">bin</span> to remove. Saved in
                this browser.
              </p>
            </div>
          </div>

          <div className="flex shrink-0 flex-wrap gap-2">
            <button
              type="button"
              onClick={() => exportManifest(store.map)}
              disabled={store.uploadedCount === 0}
              className="inline-flex h-10 items-center gap-2 rounded-sm border border-line bg-white px-4 text-[13px] font-bold text-ink transition-colors duration-300 hover:border-bronze hover:text-bronze disabled:cursor-not-allowed disabled:opacity-40"
            >
              <svg
                viewBox="0 0 24 24"
                className="h-4 w-4"
                fill="none"
                stroke="currentColor"
                strokeWidth={1.8}
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 3v12M7 10l5 5 5-5" />
                <path d="M5 21h14" />
              </svg>
              Export photos
            </button>
            <button
              type="button"
              onClick={() => {
                store.resetAll();
                setNotice("All photos reset to the original listings.");
                window.setTimeout(() => setNotice(null), 4000);
              }}
              disabled={store.uploadedCount === 0}
              className="inline-flex h-10 items-center rounded-sm border border-line bg-white px-4 text-[13px] font-bold text-ink transition-colors duration-300 hover:border-red-500 hover:text-red-600 disabled:cursor-not-allowed disabled:opacity-40"
            >
              Reset all
            </button>
          </div>
        </div>

        {/* Toast */}
        {notice && (
          <p
            role="status"
            className="reveal is-visible mt-4 inline-flex items-center gap-2 rounded-sm bg-moss px-4 py-2.5 text-[13px] font-medium text-white"
          >
            <CheckIcon className="h-4 w-4 text-whatsapp" />
            {notice}
          </p>
        )}

        {/* Filter bar */}
        <div className="reveal mt-8 grid gap-3 rounded-lg border border-line bg-white p-4 shadow-soft sm:grid-cols-3">
          {[
            {
              id: "beds",
              label: "Bedrooms",
              value: beds,
              onChange: setBeds,
              options: BEDROOM_OPTIONS,
            },
            {
              id: "guests",
              label: "Guests",
              value: guests,
              onChange: setGuests,
              options: ["Any guests", "1", "2", "4", "6", "8", "10"],
            },
            {
              id: "sort",
              label: "Sort by",
              value: sort,
              onChange: setSort,
              options: ["Featured", "Price: low to high", "Price: high to low"],
            },
          ].map((f) => (
            <label key={f.id} htmlFor={`filter-${f.id}`} className="block">
              <span className="mb-1.5 block text-[10.5px] font-bold tracking-[0.14em] text-ink-soft uppercase">
                {f.label}
              </span>
              <span className="relative block">
                <select
                  id={`filter-${f.id}`}
                  value={f.value}
                  onChange={(e) => f.onChange(e.target.value)}
                  className={selectClass}
                >
                  {f.options.map((o) => (
                    <option key={o} value={o}>
                      {f.id === "guests" && o !== "Any guests"
                        ? `${o} ${o === "1" ? "guest" : "guests"}`
                        : o}
                    </option>
                  ))}
                </select>
                <ChevronIcon className="pointer-events-none absolute top-1/2 right-3 h-4 w-4 -translate-y-1/2 text-ink-soft" />
              </span>
            </label>
          ))}
        </div>

        {/* Results meta */}
        <div className="reveal mt-5 flex flex-wrap items-center justify-between gap-3">
          <p className="text-[13.5px] text-ink-soft">
            Showing <span className="font-bold text-ink">{totalShown}</span> of{" "}
            {APARTMENTS.length} apartments across{" "}
            <span className="font-bold text-ink">{groups.length}</span> areas
          </p>
          {filtered && (
            <button
              type="button"
              onClick={reset}
              className="text-[13px] font-bold text-bronze transition-colors hover:text-bronze-soft"
            >
              Clear filters
            </button>
          )}
        </div>

        {/* Jump-to-area nav — click an area to see all its apartments */}
        <div className="reveal marquee-mask mt-6 overflow-x-auto pb-1">
          <div className="flex w-max items-center gap-2">
            <span className="mr-1 text-[11px] font-bold tracking-[0.16em] text-ink-soft uppercase">
              Jump to
            </span>
            {AREAS.map((area) => {
              const n = APARTMENTS.filter((a) => a.area === area).length;
              return (
                <a
                  key={area}
                  href={`#area-${areaSlug(area)}`}
                  className="inline-flex items-center gap-2 rounded-sm border border-line bg-white px-3.5 py-2 text-[13px] font-bold text-ink whitespace-nowrap transition-all duration-300 hover:border-bronze hover:text-bronze"
                >
                  {area}
                  <span className="rounded-full bg-shell px-1.5 py-0.5 text-[11px] font-bold text-bronze">
                    {n}
                  </span>
                </a>
              );
            })}
          </div>
        </div>
      </div>

      {/* Area sections */}
      {groups.length > 0 ? (
        <div className="pb-14 sm:pb-20">
          {groups.map((g) => (
            <AreaSection
              key={g.area}
              area={g.area}
              apartments={g.apartments}
              store={store}
              pickFile={pickFile}
            />
          ))}
        </div>
      ) : (
        <div className="mx-auto max-w-[1240px] px-5 pb-20 sm:px-8">
          <div className="rounded-lg border border-dashed border-line bg-white px-6 py-16 text-center">
            <p className="text-[16px] font-bold text-ink">
              Nothing matches those filters yet.
            </p>
            <p className="mx-auto mt-2 max-w-md text-[14px] leading-relaxed text-ink-soft">
              We have more apartments than are listed publicly. Message us with your
              dates and we'll find the right one for you.
            </p>
            <div className="mt-6 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <WhatsAppButton
                message={`Hi ${brand.name}! I'm looking for an apartment for ${guests === "Any guests" ? "2" : guests} guests. My dates are: `}
              >
                Ask on WhatsApp
              </WhatsAppButton>
              <button
                type="button"
                onClick={reset}
                className="inline-flex h-12 items-center rounded-sm border border-line px-5 text-[14px] font-bold text-ink transition-colors hover:border-bronze"
              >
                Clear filters
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Off-grid CTA */}
      <div className="mx-auto max-w-[1240px] px-5 pb-14 sm:px-8 sm:pb-20">
        <div className="reveal flex flex-col items-center gap-5 rounded-lg bg-moss px-6 py-10 text-center sm:px-12">
          <span className="grid h-12 w-12 place-items-center rounded-full bg-whatsapp text-white">
            <WhatsAppIcon className="h-6 w-6" />
          </span>
          <h3 className="max-w-xl text-[24px] leading-tight text-white sm:text-[28px]">
            Looking for something specific?
          </h3>
          <p className="max-w-lg text-[15px] leading-relaxed text-white/70">
            We have {APARTMENTS.length} apartments live across {LOCATIONS.length}{" "}
            areas, with more added every month. Send us your dates and budget and
            we'll shortlist the best three for you — with photos and a total price.
          </p>
          <div className="flex flex-col gap-3 sm:flex-row">
            <WhatsAppButton
              variant="light"
              message={`Hi ${brand.name}! I'm looking for something specific. My dates are: ____ and my budget is around ₦____ per night. What would you recommend?`}
            >
              Ask for a recommendation
            </WhatsAppButton>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Areas overview                                                      */
/* ------------------------------------------------------------------ */

export function Areas() {
  return (
    <section id="areas" className="scroll-mt-20 border-t border-line bg-white py-14 sm:py-20">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8">
        <div className="reveal flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="flex items-center gap-2.5 text-[11px] font-bold tracking-[0.22em] text-bronze uppercase">
              <span className="h-px w-7 bg-bronze" />
              Where we are
            </p>
            <h2 className="mt-4 text-[30px] leading-[1.15] text-ink sm:text-[38px]">
              <Editable
                k="section.areas.title"
                value="Browse shortlets by area"
              />
            </h2>
          </div>
          <p className="max-w-sm text-[15px] leading-relaxed text-ink-soft">
            Tap any area to open WhatsApp with your enquiry already written. Tell us
            the dates and we'll confirm what's free.
          </p>
        </div>

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {LOCATIONS.map((l, i) => (
            <a
              key={l.name}
              href={`#area-${areaSlug(l.name)}`}
              className="reveal group flex flex-col rounded-lg border border-line bg-white p-5 transition-all duration-500 hover:-translate-y-1 hover:border-bronze hover:shadow-lift"
              style={{ ["--reveal-delay" as string]: `${(i % 4) * 80}ms` }}
            >
              <span className="grid h-10 w-10 place-items-center rounded-sm bg-shell text-bronze transition-colors duration-500 group-hover:bg-bronze group-hover:text-white">
                <svg
                  viewBox="0 0 24 24"
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={1.8}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
                  <circle cx="12" cy="10" r="3" />
                </svg>
              </span>
              <h3 className="mt-4 text-[17px] font-bold text-ink">{l.name}</h3>
              <p className="mt-1.5 flex-1 text-[13.5px] leading-relaxed text-ink-soft">
                {l.blurb}
              </p>
              <span className="mt-4 flex items-center justify-between border-t border-line pt-3.5 text-[12.5px] font-bold text-bronze">
                <span className="flex items-center gap-2">
                  {l.count}
                  <span className="text-ink-soft/70">view →</span>
                </span>
                <span className="transition-transform duration-300 group-hover:translate-x-1">
                  →
                </span>
              </span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
