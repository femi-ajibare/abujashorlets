import { waLink } from "../config";
import { cn } from "../utils/cn";
import { WhatsAppIcon } from "./icons";

type Variant = "solid" | "dark" | "ghost" | "light";

const VARIANTS: Record<Variant, string> = {
  solid:
    "bg-whatsapp text-white shadow-[0_10px_30px_-8px_rgba(37,211,102,0.6)] hover:bg-[#1fbe5b] hover:shadow-[0_14px_38px_-8px_rgba(37,211,102,0.7)]",
  dark: "bg-moss text-cream hover:bg-moss-deep",
  ghost:
    "border border-ink/15 bg-white/70 text-ink hover:border-ink/30 hover:bg-white",
  light: "bg-white/12 text-cream border border-white/25 hover:bg-white/20",
};

type Props = {
  /** The pre-filled WhatsApp message body. */
  message: string;
  children: React.ReactNode;
  className?: string;
  variant?: Variant;
  size?: "sm" | "md" | "lg";
  fullWidth?: boolean;
  onClick?: () => void;
};

const SIZES = {
  sm: "h-10 px-4 text-[13px] gap-1.5 rounded-sm",
  md: "h-12 px-5 text-[14px] gap-2 rounded-sm",
  lg: "h-14 px-7 text-[15px] gap-2.5 rounded-sm",
};

export function WhatsAppButton({
  message,
  children,
  className,
  variant = "solid",
  size = "md",
  fullWidth,
  onClick,
}: Props) {
  return (
    <a
      href={waLink(message)}
      target="_blank"
      rel="noopener noreferrer"
      onClick={onClick}
      className={cn(
        "group inline-flex items-center justify-center font-semibold tracking-[-0.01em] whitespace-nowrap transition-all duration-300 ease-out active:scale-[0.98]",
        VARIANTS[variant],
        SIZES[size],
        fullWidth && "w-full",
        className,
      )}
    >
      <WhatsAppIcon className="h-[1.15em] w-[1.15em] transition-transform duration-300 group-hover:scale-110" />
      <span>{children}</span>
    </a>
  );
}
