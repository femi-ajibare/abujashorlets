import { useEffect, useState } from "react";
import { Editable, useContent } from "../content";
import { cn } from "../utils/cn";
import { WhatsAppButton } from "./WhatsAppButton";

const NAV = [
  { label: "Apartments", href: "#apartments" },
  { label: "Amenities", href: "#amenities" },
  { label: "How it works", href: "#how-it-works" },
  { label: "Reviews", href: "#reviews" },
  { label: "FAQ", href: "#faq" },
];

export function Logo({ className }: { className?: string }) {
  const { brand } = useContent();

  return (
    <span className={cn("flex items-center gap-2.5", className)}>
      <span className="relative grid h-9 w-9 place-items-center rounded-sm bg-moss text-cream shadow-sm">
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round">
          <path d="M3 10.5 12 4l9 6.5" />
          <path d="M5.5 9.8V20h13V9.8" />
          <path d="M10 20v-5h4v5" />
        </svg>
      </span>
      <span className="flex flex-col leading-none">
        <Editable
          k="brand.name"
          value={brand.name}
          className="font-display text-[19px] font-semibold tracking-[-0.02em]"
        />
        <Editable
          k="brand.tagline"
          value={brand.tagline}
          className="mt-[3px] text-[9.5px] font-semibold tracking-[0.16em] text-ink-soft/70 uppercase"
        />
      </span>
    </span>
  );
}

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { brand, wa } = useContent();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500 ease-out",
        scrolled
          ? "border-b border-line/70 bg-cream/90 backdrop-blur-xl"
          : "border-b border-transparent",
      )}
    >
      <div className="mx-auto flex h-[72px] max-w-[1240px] items-center justify-between gap-4 px-5 sm:px-8">
        <a href="#top" className="transition-opacity hover:opacity-80">
          <Logo />
        </a>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((item, i) => (
            <a
              key={item.href}
              href={item.href}
              className="relative rounded-full px-3.5 py-2 text-[14px] font-medium text-ink-soft transition-colors hover:text-ink"
            >
              <Editable
                k={`nav.${i}.label`}
                value={item.label}
                className="text-[14px] font-medium"
              />
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href={`tel:${brand.whatsappDisplay.replace(/\s/g, "")}`}
            className="hidden text-[14px] font-medium text-ink-soft transition-colors hover:text-ink sm:block"
          >
            <Editable k="brand.whatsappDisplay" value={brand.whatsappDisplay} />
          </a>
          <WhatsAppButton
            size="sm"
            className="hidden sm:inline-flex"
            message={`Hi ${brand.name}! I'd like to check availability for a stay.`}
          >
            Book on WhatsApp
          </WhatsAppButton>

          <button
            type="button"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className="grid h-10 w-10 place-items-center rounded-full border border-line bg-white/70 text-ink lg:hidden"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round">
              {open ? <path d="M6 6l12 12M18 6 6 18" /> : <path d="M4 8h16M4 16h16" />}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      <div
        className={cn(
          "overflow-hidden border-t border-line bg-cream transition-[max-height,opacity] duration-500 ease-out lg:hidden",
          open ? "max-h-[520px] opacity-100" : "max-h-0 opacity-0",
        )}
      >
        <div className="space-y-1 px-5 py-5">
          {NAV.map((item, i) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="block rounded-sm px-3 py-3 text-[15px] font-medium text-ink transition-colors hover:bg-shell"
            >
              <Editable
                k={`nav.${i}.label`}
                value={item.label}
                className="text-[15px] font-medium"
              />
            </a>
          ))}
          <div className="pt-3">
            <WhatsAppButton
              fullWidth
              size="md"
              message={wa(
                `Hi ${brand.name}! I'd like to check availability for a stay.`,
              )}
            >
              Book on WhatsApp
            </WhatsAppButton>
          </div>
          <p className="px-3 pt-3 text-[13px] text-ink-soft">
            <Editable k="brand.whatsappDisplay" value={brand.whatsappDisplay} />
            <span className="mx-1.5">·</span>
            <Editable k="brand.hours" value={brand.hours} />
          </p>
        </div>
      </div>
    </header>
  );
}
