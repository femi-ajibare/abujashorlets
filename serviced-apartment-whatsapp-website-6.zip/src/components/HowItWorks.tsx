import { STEPS } from "../data";
import { Editable, useContent } from "../content";
import { SectionHeading } from "./primitives";
import { CheckIcon, WhatsAppIcon } from "./icons";

const PHONE_CHAT = [
  { from: "them", text: "Hi Abuja Shortlets! Is the Maitama Sky free 12–15 June for 2 people?" },
  { from: "us", text: "Hi Ada 👋 Yes it is! ₦435,000 total incl. cleaning. Shall I hold it?" },
  { from: "them", text: "Yes please. Sending payment now." },
  { from: "us", text: "Received ✅ Door code 4812. Check-in from 2pm. Enjoy your stay!" },
];

export function HowItWorks() {
  const { brand } = useContent();
  return (
    <section id="how-it-works" className="scroll-mt-20 bg-cream py-20 sm:py-28">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8">
        <SectionHeading
          align="center"
          eyebrow="How booking works"
          title={
            <Editable
              k="section.how.title"
              value="Three taps. No forms, no accounts, no waiting."
            />
          }
          description="We don't believe a weekend away should need a registration form. Booking an Abuja Shortlets apartment takes about as long as texting a friend."
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {STEPS.map((s, i) => (
            <div
              key={s.title}
              className="reveal relative rounded-lg border border-line bg-white p-7"
              style={{ ["--reveal-delay" as string]: `${i * 110}ms` }}
            >
              <span className="absolute -top-5 left-7 grid h-11 w-11 place-items-center rounded-full bg-bronze font-display text-[17px] font-semibold text-white shadow-soft">
                {i + 1}
              </span>
              <h3 className="mt-4 text-[22px] leading-snug text-ink">
                <Editable k={`step.${i}.title`} value={s.title} />
              </h3>
              <p className="mt-3 text-[14.5px] leading-relaxed text-ink-soft">
                <Editable k={`step.${i}.desc`} value={s.description} multiline />
              </p>
              {i < STEPS.length - 1 && (
                <span
                  aria-hidden
                  className="absolute top-1/2 -right-3 hidden text-line lg:block"
                >
                  <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round">
                    <path d="m9 6 6 6-6 6" />
                  </svg>
                </span>
              )}
            </div>
          ))}
        </div>

        {/* Mock WhatsApp conversation */}
        <div className="reveal mt-16 grid items-center gap-10 rounded-lg border border-line bg-shell p-6 sm:p-10 lg:grid-cols-[0.85fr_1fr] lg:gap-14">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-whatsapp/15 px-3 py-1.5 text-[12px] font-semibold text-whatsapp-dark">
              <WhatsAppIcon className="h-4 w-4" />
              A real booking, start to finish
            </span>
            <h3 className="mt-5 text-[30px] leading-tight text-ink sm:text-[36px]">
              The whole thing happens in one chat.
            </h3>
            <p className="mt-4 text-[15px] leading-relaxed text-ink-soft">
              Availability, the quote, payment and your door code — all in one thread
              you can scroll back to any time. No inbox digging, no reference numbers
              to chase.
            </p>
            <ul className="mt-6 space-y-3">
              {[
                "Average reply time: under 10 minutes",
                "Human concierge, 7am – 11pm daily",
                "Receipts and booking details kept in the chat",
              ].map((t) => (
                <li key={t} className="flex items-start gap-2.5 text-[14px] text-ink">
                  <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-whatsapp/20 text-whatsapp-dark">
                    <CheckIcon className="h-3 w-3" />
                  </span>
                  {t}
                </li>
              ))}
            </ul>
          </div>

          <div className="mx-auto w-full max-w-[380px]">
            <div className="overflow-hidden rounded-lg bg-shell shadow-lift ring-1 ring-black/5">
              <div className="flex items-center gap-3 bg-[#075e54] px-4 py-3">
                <span className="grid h-9 w-9 place-items-center rounded-full bg-white/15 text-white">
                  <WhatsAppIcon className="h-5 w-5" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[14px] font-semibold text-white">
                    {brand.name} Concierge
                  </span>
                  <span className="block text-[11px] text-white/70">online</span>
                </span>
                <span className="text-[11px] font-medium text-white/70">2 min</span>
              </div>

              <div
                className="space-y-2.5 px-3.5 py-4"
                style={{
                  backgroundImage:
                    "radial-gradient(rgba(0,0,0,0.035) 1px, transparent 1px)",
                  backgroundSize: "14px 14px",
                }}
              >
                {PHONE_CHAT.map((m, i) => (
                  <div
                    key={i}
                    className={`flex ${m.from === "them" ? "justify-end" : "justify-start"}`}
                  >
                    <p
                      className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-[13px] leading-relaxed shadow-sm ${
                        m.from === "them"
                          ? "rounded-br-md bg-[#d9fdd3] text-[#111b21]"
                          : "rounded-bl-md bg-white text-[#111b21]"
                      }`}
                    >
                      {m.text}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
