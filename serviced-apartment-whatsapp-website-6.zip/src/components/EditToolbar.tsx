import { useState } from "react";
import { useContent } from "../content";
import { cn } from "../utils/cn";
import { WhatsAppIcon } from "./icons";

/**
 * Floating edit-mode control: toggle inline editing, jump to settings,
 * export every change as JSON, or reset back to the baked-in content.
 */

const BRAND_FIELDS: {
  key: string;
  label: string;
  hint?: string;
  type?: "text" | "number";
}[] = [
  { key: "brand.name", label: "Business name" },
  { key: "brand.tagline", label: "Tagline" },
  { key: "brand.city", label: "City" },
  {
    key: "brand.whatsappNumber",
    label: "WhatsApp number",
    hint: "International format, digits only — e.g. 2348132714544",
  },
  { key: "brand.whatsappDisplay", label: "Number as shown to visitors" },
  { key: "brand.email", label: "Email address" },
  { key: "brand.address", label: "Office address" },
  { key: "brand.hours", label: "Concierge hours" },
  { key: "brand.instagram", label: "Instagram URL" },
  { key: "brand.rating", label: "Star rating", type: "number" },
  { key: "brand.reviews", label: "Review count", type: "number" },
];

function exportContent(overrides: Record<string, string>) {
  const payload = {
    note: "Content overrides for Abuja Shortlets. Apply these to src/config.ts and src/data.ts, then rebuild.",
    generated: new Date().toISOString(),
    overrides,
  };
  const json = JSON.stringify(payload, null, 2);
  const blob = new Blob([json], { type: "application/json" });
  const a = document.createElement("a");
  a.download = "site-content.json";
  if (typeof URL.createObjectURL === "function") {
    a.href = URL.createObjectURL(blob);
    document.body.appendChild(a);
    a.click();
    a.remove();
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    a.href = reader.result as string;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };
  reader.readAsDataURL(blob);
}

export function EditToolbar() {
  const {
    editing,
    setEditing,
    overrides,
    set,
    unset,
    resetAll,
    dirtyCount,
    brand,
  } = useContent();
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<"content" | "settings">("settings");

  const btn =
    "inline-flex h-9 items-center justify-center gap-1.5 rounded-sm px-3 text-[12.5px] font-bold transition-colors duration-200";

  return (
    <>
      {/* Toggle tab */}
      <button
        type="button"
        onClick={() => setEditing(!editing)}
        className={cn(
          "fixed bottom-5 left-5 z-[60] inline-flex h-12 items-center gap-2 rounded-full px-5 text-[13.5px] font-bold shadow-lift transition-all duration-300 active:scale-95",
          editing
            ? "bg-bronze text-white"
            : "bg-moss text-white hover:bg-moss-deep",
        )}
      >
        <svg
          viewBox="0 0 24 24"
          className="h-4.5 w-4.5"
          fill="none"
          stroke="currentColor"
          strokeWidth={1.9}
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M12 20h9" />
          <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z" />
        </svg>
        {editing ? "Done editing" : "Edit site"}
        {!editing && dirtyCount > 0 && (
          <span className="rounded-full bg-bronze px-1.5 py-0.5 text-[10px] text-white">
            {dirtyCount}
          </span>
        )}
      </button>

      {/* Settings drawer */}
      {open && (
        <div className="fixed inset-0 z-[70] flex items-end justify-center bg-ink/40 p-0 backdrop-blur-sm sm:items-center sm:p-6">
          <div className="flex max-h-[88vh] w-full max-w-[560px] flex-col overflow-hidden rounded-t-lg bg-white shadow-lift sm:rounded-lg">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <div>
                <h3 className="text-[17px] font-bold text-ink">Site settings</h3>
                <p className="mt-0.5 text-[12.5px] text-ink-soft">
                  {dirtyCount > 0
                    ? `${dirtyCount} change${dirtyCount === 1 ? "" : "s"} saved in this browser`
                    : "No changes yet"}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close settings"
                className="grid h-9 w-9 place-items-center rounded-sm border border-line text-ink transition-colors hover:border-ink/30"
              >
                <svg
                  viewBox="0 0 24 24"
                  className="h-4 w-4"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  strokeLinecap="round"
                >
                  <path d="M6 6l12 12M18 6 6 18" />
                </svg>
              </button>
            </div>

            {/* Tabs */}
            <div className="flex gap-1 border-b border-line px-5 pt-3">
              {(
                [
                  ["settings", "Business details"],
                  ["content", `All edits (${dirtyCount})`],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setTab(id)}
                  className={cn(
                    "rounded-t-sm px-3.5 py-2.5 text-[13px] font-bold transition-colors",
                    tab === id
                      ? "border-b-2 border-bronze text-ink"
                      : "text-ink-soft hover:text-ink",
                  )}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto px-5 py-5">
              {tab === "settings" ? (
                <div className="space-y-4">
                  <p className="rounded-sm bg-shell px-3.5 py-3 text-[13px] leading-relaxed text-ink-soft">
                    These values feed every button, link and phone number on the
                    site. Change them here and the whole site updates instantly.
                  </p>
                  {BRAND_FIELDS.map((f) => {
                    const current =
                      overrides[f.key] ??
                      String(
                        (brand as unknown as Record<string, string | number>)[
                          f.key.replace("brand.", "")
                        ] ?? "",
                      );
                    return (
                      <label key={f.key} className="block">
                        <span className="mb-1.5 block text-[12px] font-bold tracking-[0.1em] text-ink-soft uppercase">
                          {f.label}
                        </span>
                        <span className="relative block">
                          <input
                            type={f.type ?? "text"}
                            value={current}
                            onChange={(e) => set(f.key, e.target.value)}
                            className="w-full rounded-sm border border-line bg-white px-3.5 py-2.5 text-[14px] font-medium text-ink transition-colors focus:border-bronze focus:outline-none"
                          />
                          {overrides[f.key] != null && (
                            <button
                              type="button"
                              onClick={() => unset(f.key)}
                              title="Revert to original"
                              className="absolute top-1/2 right-2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-sm text-ink-soft transition-colors hover:bg-shell hover:text-ink"
                            >
                              <svg
                                viewBox="0 0 24 24"
                                className="h-3.5 w-3.5"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth={2}
                                strokeLinecap="round"
                              >
                                <path d="M6 6l12 12M18 6 6 18" />
                              </svg>
                            </button>
                          )}
                        </span>
                        {f.hint && (
                          <span className="mt-1 block text-[11.5px] text-ink-soft/80">
                            {f.hint}
                          </span>
                        )}
                      </label>
                    );
                  })}

                  <div className="rounded-sm border border-line bg-shell/60 p-4">
                    <p className="text-[12.5px] font-bold text-ink">
                      WhatsApp booking link
                    </p>
                    <a
                      href={brand.whatsappShortLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-1.5 inline-flex items-center gap-2 text-[13px] font-bold text-whatsapp-dark hover:underline"
                    >
                      <WhatsAppIcon className="h-4 w-4" />
                      wa.link/hc0a3b
                    </a>
                    <p className="mt-2 text-[11.5px] leading-relaxed text-ink-soft">
                      The short link is set in <code>src/config.ts</code> and isn’t
                      editable here.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  {dirtyCount === 0 ? (
                    <p className="py-10 text-center text-[14px] text-ink-soft">
                      Nothing edited yet. Turn on “Edit site” and click any text on
                      the page to change it.
                    </p>
                  ) : (
                    Object.entries(overrides).map(([key, value]) => (
                      <div
                        key={key}
                        className="flex items-start justify-between gap-3 rounded-sm border border-line px-3.5 py-2.5"
                      >
                        <div className="min-w-0">
                          <p className="truncate text-[11px] font-bold tracking-[0.08em] text-bronze uppercase">
                            {key}
                          </p>
                          <p className="mt-1 line-clamp-2 text-[13px] text-ink">
                            {value || <em className="text-ink-soft">(empty)</em>}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => unset(key)}
                          className="shrink-0 text-[12px] font-bold text-ink-soft transition-colors hover:text-red-600"
                        >
                          Revert
                        </button>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="flex flex-wrap gap-2 border-t border-line px-5 py-4">
              <button
                type="button"
                onClick={() => exportContent(overrides)}
                disabled={dirtyCount === 0}
                className={cn(
                  btn,
                  "bg-moss text-white hover:bg-moss-deep disabled:cursor-not-allowed disabled:opacity-40",
                )}
              >
                Export changes
              </button>
              <button
                type="button"
                onClick={() => {
                  if (window.confirm("Revert every edit back to the original content?")) {
                    resetAll();
                  }
                }}
                disabled={dirtyCount === 0}
                className={cn(
                  btn,
                  "border border-line text-ink hover:border-red-500 hover:text-red-600 disabled:cursor-not-allowed disabled:opacity-40",
                )}
              >
                Reset everything
              </button>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className={cn(btn, "ml-auto text-ink-soft hover:text-ink")}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Open settings */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="fixed bottom-5 left-[132px] z-[60] hidden h-12 items-center gap-2 rounded-full bg-white px-4 text-[13px] font-bold text-ink shadow-lift ring-1 ring-line transition-colors hover:ring-bronze sm:inline-flex"
      >
        <svg
          viewBox="0 0 24 24"
          className="h-4 w-4"
          fill="none"
          stroke="currentColor"
          strokeWidth={1.8}
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="3" />
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z" />
        </svg>
        Settings
      </button>

      {/* Edit-mode banner */}
      {editing && (
        <div className="fixed inset-x-0 top-0 z-[65] bg-bronze px-4 py-2.5 text-center text-[12.5px] font-bold text-white">
          Edit mode is on — click any text on the page to change it. Press “Done
          editing” when you’re finished.
        </div>
      )}
    </>
  );
}
