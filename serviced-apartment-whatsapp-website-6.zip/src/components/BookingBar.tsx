import { useMemo, useState } from "react";
import { Editable, useContent } from "../content";
import { APARTMENTS } from "../data";
import { WhatsAppButton } from "./WhatsAppButton";
import { ClockIcon } from "./icons";

const AREAS = ["Any area", ...Array.from(new Set(APARTMENTS.map((a) => a.area)))];

function todayISO(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().slice(0, 10);
}

function prettyDate(iso: string) {
  if (!iso) return "flexible";
  const d = new Date(iso + "T00:00:00");
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}

export function BookingBar() {
  const { brand } = useContent();
  const [checkIn, setCheckIn] = useState(todayISO(7));
  const [checkOut, setCheckOut] = useState(todayISO(10));
  const [guests, setGuests] = useState("2");
  const [area, setArea] = useState(AREAS[0]);

  const message = useMemo(() => {
    const nights =
      checkIn && checkOut
        ? Math.max(
            1,
            Math.round(
              (new Date(checkOut).getTime() - new Date(checkIn).getTime()) / 86400000,
            ),
          )
        : 0;
    return [
      `Hi ${brand.name}! I'd like to check availability.`,
      ``,
      `• Area: ${area}`,
      `• Check-in: ${prettyDate(checkIn)}`,
      `• Check-out: ${prettyDate(checkOut)}`,
      nights ? `• Nights: ${nights}` : null,
      `• Guests: ${guests}`,
      ``,
      `Could you confirm what's available and share a quote?`,
    ]
      .filter(Boolean)
      .join("\n");
  }, [area, checkIn, checkOut, guests]);

  const fields = [
    {
      id: "check-in",
      label: "Check-in",
      value: checkIn,
      onChange: (v: string) => {
        setCheckIn(v);
        if (new Date(v) >= new Date(checkOut)) {
          const next = new Date(v);
          next.setDate(next.getDate() + 2);
          setCheckOut(next.toISOString().slice(0, 10));
        }
      },
      type: "date",
      min: todayISO(0),
    },
    {
      id: "check-out",
      label: "Check-out",
      value: checkOut,
      onChange: setCheckOut,
      type: "date",
      min: checkIn,
    },
    { id: "guests", label: "Guests", value: guests, onChange: setGuests, type: "select" },
    { id: "area", label: "Area", value: area, onChange: setArea, type: "select", options: AREAS },
  ];

  return (
    <section className="relative z-30 -mt-2 px-5 sm:px-8">
      <div className="reveal mx-auto max-w-[1240px] rounded-lg border border-line bg-white p-3 shadow-lift sm:p-4">
        <div className="grid gap-3 lg:grid-cols-[1fr_1fr_1fr_1fr_auto]">
          {fields.map((f) => (
            <label
              key={f.id}
              htmlFor={f.id}
              className="group cursor-pointer rounded-sm bg-shell px-4 py-3 transition-colors duration-300 hover:bg-shell focus-within:bg-shell focus-within:ring-2 focus-within:ring-bronze/40"
            >
              <span className="block text-[10.5px] font-semibold tracking-[0.16em] text-ink-soft/70 uppercase">
                {f.label}
              </span>
              {f.type === "date" ? (
                <input
                  id={f.id}
                  type="date"
                  value={f.value}
                  min={f.min}
                  onChange={(e) => f.onChange(e.target.value)}
                  className="mt-1.5 w-full cursor-pointer border-none bg-transparent p-0 text-[15px] font-semibold text-ink outline-none"
                />
              ) : (
                <select
                  id={f.id}
                  value={f.value}
                  onChange={(e) => f.onChange(e.target.value)}
                  className="mt-1.5 w-full cursor-pointer appearance-none border-none bg-transparent p-0 text-[15px] font-semibold text-ink outline-none"
                >
                  {f.options
                    ? f.options.map((o) => <option key={o}>{o}</option>)
                    : Array.from({ length: 8 }, (_, i) => i + 1).map((n) => (
                        <option key={n} value={String(n)}>
                          {n} {n === 1 ? "guest" : "guests"}
                        </option>
                      ))}
                </select>
              )}
            </label>
          ))}

          <div className="flex flex-col justify-center">
            <WhatsAppButton
              size="lg"
              fullWidth
              className="lg:h-[68px] lg:px-8"
              message={message}
            >
              Check availability
            </WhatsAppButton>
          </div>
        </div>

        <p className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 px-2 pb-1 text-[12.5px] text-ink-soft">
          <ClockIcon className="h-4 w-4 text-moss" />
          <span>
            <Editable
              k="bookingbar.note"
              value="Sends your dates straight to WhatsApp — our concierge replies in about 10 minutes. No account, no forms."
              multiline
            />
          </span>
        </p>
      </div>
    </section>
  );
}
