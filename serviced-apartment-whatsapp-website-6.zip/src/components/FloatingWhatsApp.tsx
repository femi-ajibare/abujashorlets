import { useEffect, useState } from "react";
import { BRAND, waLink } from "../config";
import { cn } from "../utils/cn";
import { WhatsAppIcon } from "./icons";

/**
 * Persistent WhatsApp entry point. After a short delay a small teaser
 * bubble slides in to nudge visitors, then collapses into the round button.
 */
export function FloatingWhatsApp() {
  const [visible, setVisible] = useState(false);
  const [teaserOpen, setTeaserOpen] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 420);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!visible || dismissed) return;
    const t = window.setTimeout(() => setTeaserOpen(true), 2600);
    return () => window.clearTimeout(t);
  }, [visible, dismissed]);

  const closeTeaser = () => {
    setTeaserOpen(false);
    setDismissed(true);
  };

  return (
    <div
      className={cn(
        "fixed right-4 bottom-4 z-50 flex flex-col items-end gap-3 transition-all duration-500 ease-out sm:right-6 sm:bottom-6",
        visible ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0",
      )}
    >
      {/* Teaser card */}
      <div
        className={cn(
          "w-[min(310px,calc(100vw-2rem))] origin-bottom-right overflow-hidden rounded-2xl bg-white shadow-lift ring-1 ring-line transition-all duration-500 ease-out",
          teaserOpen && !dismissed
            ? "scale-100 opacity-100"
            : "pointer-events-none scale-90 opacity-0",
        )}
      >
        <div className="flex items-start gap-3 bg-whatsapp-dark px-4 py-3 text-white">
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/20">
            <WhatsAppIcon className="h-5 w-5" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[13.5px] font-semibold">{BRAND.name}</span>
            <span className="block text-[11.5px] text-white/75">
              Typically replies in minutes
            </span>
          </span>
          <button
            type="button"
            onClick={closeTeaser}
            aria-label="Dismiss"
            className="-mr-1 -mt-1 grid h-7 w-7 place-items-center rounded-full text-white/80 transition-colors hover:bg-white/15 hover:text-white"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
              <path d="M6 6l12 12M18 6 6 18" />
            </svg>
          </button>
        </div>
        <a
          href={waLink(
            `Hi ${BRAND.name}! I'd like to check availability for an apartment.`,
          )}
          target="_blank"
          rel="noopener noreferrer"
          onClick={closeTeaser}
          className="block px-4 py-4 transition-colors hover:bg-shell/60"
        >
          <p className="text-[14px] leading-relaxed text-ink">
            Hi there! 👋 Looking for a shortlet in Abuja? Send us your dates and we'll
            check what's free right now.
          </p>
          <span className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-semibold text-whatsapp-dark">
            Start chat
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 12h14M13 6l6 6-6 6" />
            </svg>
          </span>
        </a>
      </div>

      {/* Round button */}
      <div className="relative">
        <span className="absolute inset-0 rounded-full bg-whatsapp/40 ping-soft" aria-hidden />
        <a
          href={waLink(
            `Hi ${BRAND.name}! I'd like to check availability for an apartment.`,
          )}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Chat with us on WhatsApp"
          onClick={() => {
            setTeaserOpen(false);
            setDismissed(true);
          }}
          className="relative grid h-14 w-14 place-items-center rounded-full bg-whatsapp text-white shadow-[0_12px_30px_-6px_rgba(37,211,102,0.65)] transition-transform duration-300 hover:scale-105 active:scale-95 sm:h-16 sm:w-16"
        >
          <WhatsAppIcon className="h-7 w-7 sm:h-8 sm:w-8" />
        </a>
      </div>
    </div>
  );
}
