import { useState } from "react";
import { Editable, useContent } from "../content";
import { FAQS } from "../data";
import { cn } from "../utils/cn";
import { WhatsAppButton } from "./WhatsAppButton";
import { SectionHeading } from "./primitives";
import { ChevronIcon, WhatsAppIcon } from "./icons";

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  const { brand } = useContent();

  return (
    <section id="faq" className="scroll-mt-20 bg-white py-14 sm:py-20">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20">
          <div>
            <SectionHeading
              eyebrow="Good to know"
              title="Questions guests ask before booking"
              description="Anything not covered here? Our concierge answers in the WhatsApp chat in minutes."
            />
            <div className="reveal mt-8 rounded-lg border border-line bg-shell p-6">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-whatsapp/15 text-whatsapp-dark">
                <WhatsAppIcon className="h-6 w-6" />
              </span>
              <p className="mt-4 text-[15px] leading-relaxed text-ink-soft">
                Still unsure about something? Ask us directly — no bots, no ticket
                numbers.
              </p>
              <WhatsAppButton
                fullWidth
                className="mt-5"
                message={`Hi ${brand.name}! I have a quick question before booking: `}
              >
                Ask a question
              </WhatsAppButton>
            </div>
          </div>

          <div className="divide-y divide-line overflow-hidden rounded-lg border border-line bg-white">
            {FAQS.map((f, i) => {
              const isOpen = open === i;
              return (
                <div key={f.q}>
                  <button
                    type="button"
                    onClick={() => setOpen(isOpen ? null : i)}
                    aria-expanded={isOpen}
                    className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left transition-colors duration-300 hover:bg-shell/50"
                  >
                    <span
                      className={cn(
                        "text-[16px] font-semibold transition-colors duration-300",
                        isOpen ? "text-moss" : "text-ink",
                      )}
                    >
                      <Editable k={`faq.${i}.q`} value={f.q} />
                    </span>
                    <span
                      className={cn(
                        "grid h-8 w-8 shrink-0 place-items-center rounded-full border transition-all duration-500",
                        isOpen
                          ? "rotate-180 border-bronze bg-bronze text-white"
                          : "border-line text-ink-soft",
                      )}
                    >
                      <ChevronIcon className="h-4 w-4" />
                    </span>
                  </button>
                  <div
                    className={cn(
                      "grid transition-[grid-template-rows] duration-500 ease-out",
                      isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]",
                    )}
                  >
                    <div className="overflow-hidden">
                      <p className="px-6 pb-6 text-[14.5px] leading-relaxed text-ink-soft">
                        <Editable k={`faq.${i}.a`} value={f.a} multiline />
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
