import { Editable, useContent } from "../content";
import { AMENITIES, GALLERY } from "../data";
import { WhatsAppButton } from "./WhatsAppButton";
import { AmenityIcon } from "./icons";

export function Amenities() {
  const { brand, wa } = useContent();
  return (
    <section id="amenities" className="relative scroll-mt-20 overflow-hidden bg-shell py-14 sm:py-20">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.05fr] lg:items-start lg:gap-16">
          <div>
            <p className="reveal inline-flex items-center gap-2.5 text-[11px] font-bold tracking-[0.22em] text-bronze uppercase">
              <span className="h-px w-7 bg-bronze" />
              <Editable k="section.amenities.eyebrow" value="Included as standard" />
            </p>
            <h2 className="reveal mt-4 text-[30px] leading-[1.15] text-ink sm:text-[38px]">
              <Editable
                k="section.amenities.title"
                value="Everything a home should have. Nothing a hotel charges extra for."
              />
            </h2>
            <p className="reveal mt-4 max-w-lg text-[15px] leading-relaxed text-ink-soft">
              <Editable
                k="section.amenities.sub"
                value={`We built ${brand.name} around the things that actually ruin a trip: no power, no internet, no hot water, no one to call. All of it is handled before you arrive.`}
                multiline
              />
            </p>

            <div className="reveal mt-7">
              <WhatsAppButton
                size="lg"
                message={`Hi ${brand.name}! What's included with the apartments? Could you send me the full amenity list and a few photos?`}
              >
                Ask about amenities
              </WhatsAppButton>
            </div>

            <div className="reveal mt-10 grid gap-4 sm:grid-cols-3">
              {GALLERY.map((g, i) => (
                <figure
                  key={g.image}
                  className="group relative overflow-hidden rounded-sm ring-1 ring-black/5"
                  style={{ ["--reveal-delay" as string]: `${i * 100}ms` }}
                >
                  <img
                    src={g.image}
                    alt={g.caption}
                    loading="lazy"
                    className="h-52 w-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-110"
                  />
                  <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/85 to-transparent px-3 pt-8 pb-3 text-[12px] font-medium text-white/95">
                    {g.caption}
                  </figcaption>
                </figure>
              ))}
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {AMENITIES.map((a, i) => (
              <div
                key={a.title}
                className="reveal group rounded-sm border border-line bg-white p-6 transition-all duration-500 hover:-translate-y-1 hover:border-bronze hover:shadow-lift"
                style={{ ["--reveal-delay" as string]: `${(i % 2) * 90}ms` }}
              >
                <span className="grid h-11 w-11 place-items-center rounded-sm bg-shell text-bronze transition-colors duration-500 group-hover:bg-bronze group-hover:text-white">
                  <AmenityIcon name={a.icon} className="h-6 w-6" />
                </span>
                <h3 className="mt-4 text-[16px] leading-snug font-bold text-ink">
                  <Editable k={`amenity.${i}.title`} value={a.title} />
                </h3>
                <p className="mt-2 text-[13.5px] leading-relaxed text-ink-soft">
                  <Editable k={`amenity.${i}.desc`} value={a.description} multiline />
                </p>
              </div>
            ))}

            <a
              href={wa(
                `Hi ${brand.name}! I have a question about the apartments: `,
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="reveal flex flex-col justify-center rounded-sm border border-dashed border-bronze/50 bg-white/60 p-6 transition-colors duration-300 hover:bg-white"
            >
              <span className="text-[18px] font-bold text-ink">
                Something else you need?
              </span>
              <span className="mt-2 text-[13.5px] leading-relaxed text-ink-soft">
                Early check-in, a crib, a private chef, an extra parking space —
                just ask in the chat.
              </span>
              <span className="mt-4 text-[13px] font-bold text-bronze">
                Message us →
              </span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
