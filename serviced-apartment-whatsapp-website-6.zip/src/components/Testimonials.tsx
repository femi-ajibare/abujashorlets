import { Editable, EditableNumber, useContent } from "../content";
import { TESTIMONIALS } from "../data";
import { SectionHeading } from "./primitives";
import { StarIcon } from "./icons";

function Avatar({ initials, delay }: { initials: string; delay: number }) {
  return (
    <span
      className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-gradient-to-br from-bronze-soft to-bronze font-display text-[14px] font-semibold text-white"
      style={{ animationDelay: `${delay}ms` }}
    >
      {initials}
    </span>
  );
}

export function Testimonials() {
  const { brand } = useContent();
  return (
    <section id="reviews" className="scroll-mt-20 bg-shell py-20 sm:py-28">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8">
        <SectionHeading
          align="center"
          eyebrow="Guest reviews"
          title={
          <>
            Rated <EditableNumber k="brand.rating" value={brand.rating} /> out of 5 by{" "}
            <EditableNumber k="brand.reviews" value={brand.reviews} /> guests
          </>
        }
          description="From two-night work trips to month-long family stays — here's what people say after they've checked out."
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {TESTIMONIALS.map((t, i) => (
            <figure
              key={t.name}
              className="reveal flex flex-col rounded-lg border border-line bg-white p-7"
              style={{ ["--reveal-delay" as string]: `${i * 110}ms` }}
            >
              <div className="flex items-center gap-1 text-bronze">
                {Array.from({ length: 5 }).map((_, s) => (
                  <StarIcon key={s} className="h-4 w-4" />
                ))}
              </div>
              <blockquote className="mt-5 flex-1 text-[15px] leading-[1.75] text-ink-soft">
                <span className="font-display text-[26px] leading-none text-bronze/50">
                  “
                </span>
                <Editable k={`testimonial.${i}.quote`} value={t.quote} multiline />
              </blockquote>
              <figcaption className="mt-6 flex items-center gap-3 border-t border-line pt-5">
                <Avatar initials={t.initials} delay={i * 150} />
                <span>
                  <span className="block text-[14.5px] font-semibold text-ink">
                    {t.name}
                  </span>
                  <span className="block text-[12.5px] text-ink-soft/80">{t.role}</span>
                </span>
              </figcaption>
            </figure>
          ))}
        </div>

        {/* Logo / trust marquee */}
        <div className="reveal marquee-mask mt-16 overflow-hidden">
          <div className="marquee-track flex w-max items-center gap-12">
            {[...TRUST, ...TRUST].map((t, i) => (
              <span
                key={i}
                className="flex items-center gap-2.5 text-[13px] font-semibold tracking-[0.14em] whitespace-nowrap text-ink-soft/45 uppercase"
              >
                <StarIcon className="h-3.5 w-3.5 text-bronze/50" />
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

const TRUST = [
  "Trusted by 1,200+ guests",
  "Verified by Airbnb hosts",
  "Corporate travel ready",
  "Relocation & long stays",
  "Airport pickup available",
  "24/7 concierge",
];
