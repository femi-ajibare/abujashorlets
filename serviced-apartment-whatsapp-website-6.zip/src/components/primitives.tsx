import { cn } from "../utils/cn";

export function Eyebrow({
  children,
  className,
  tone = "dark",
}: {
  children: React.ReactNode;
  className?: string;
  tone?: "dark" | "light";
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 text-[11px] font-semibold tracking-[0.22em] uppercase",
        tone === "dark" ? "text-bronze" : "text-bronze-soft",
        className,
      )}
    >
      <span className="h-px w-6 bg-current opacity-60" />
      {children}
    </span>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  tone = "dark",
  align = "left",
  className,
}: {
  eyebrow: string;
  title: React.ReactNode;
  description?: React.ReactNode;
  tone?: "dark" | "light";
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div
      className={cn(
        "reveal max-w-2xl",
        align === "center" && "mx-auto text-center",
        className,
      )}
    >
      <Eyebrow tone={tone} className={align === "center" ? "justify-center" : ""}>
        {eyebrow}
      </Eyebrow>
      <h2
        className={cn(
          "mt-4 text-4xl leading-[1.08] sm:text-5xl",
          tone === "dark" ? "text-ink" : "text-cream",
        )}
      >
        {title}
      </h2>
      {description && (
        <p
          className={cn(
            "mt-5 text-[15.5px] leading-relaxed sm:text-base",
            tone === "dark" ? "text-ink-soft" : "text-cream/70",
            align === "center" && "mx-auto",
          )}
        >
          {description}
        </p>
      )}
    </div>
  );
}

export function Pill({
  children,
  className,
  tone = "dark",
}: {
  children: React.ReactNode;
  className?: string;
  tone?: "dark" | "light";
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-sm px-3 py-1.5 text-[12px] font-medium",
        tone === "dark"
          ? "bg-shell text-ink-soft ring-1 ring-line"
          : "bg-white/10 text-cream/85 ring-1 ring-white/15",
        className,
      )}
    >
      {children}
    </span>
  );
}
