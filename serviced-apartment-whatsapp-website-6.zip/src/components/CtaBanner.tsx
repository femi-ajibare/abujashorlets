import { Editable, useContent } from "../content";
import { LOCATIONS } from "../data";
import { WhatsAppButton } from "./WhatsAppButton";
import { WhatsAppIcon } from "./icons";
import { CheckIcon, ClockIcon, MailIcon, PinIcon, StarIcon } from "./icons";

export function FinalCta() {
  const { brand } = useContent();
  return (
    <section className="px-5 pb-20 sm:px-8 sm:pb-28">
      <div className="reveal relative mx-auto max-w-[1240px] overflow-hidden rounded-lg bg-moss-deep px-6 py-16 text-center sm:px-12 sm:py-20">
        <div
          aria-hidden
          className="pointer-events-none absolute -top-24 left-1/2 h-[380px] w-[620px] -translate-x-1/2 rounded-full bg-bronze/20 blur-[120px]"
        />

        <div className="relative grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:gap-16">
          <div className="text-center lg:text-left">
            <span className="inline-flex items-center gap-2 rounded-sm bg-white/10 px-3.5 py-1.5 text-[12px] font-semibold text-cream/80 ring-1 ring-white/15">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full rounded-full bg-whatsapp ping-soft opacity-70" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-whatsapp" />
              </span>
              Concierge online now · <Editable k="brand.hours" value={brand.hours} />
            </span>

            <h2 className="mx-auto mt-7 max-w-2xl text-[36px] leading-[1.06] text-cream sm:text-[52px] lg:mx-0">
              <Editable k="cta.title" value="Your next stay is one message away." />
            </h2>
            <p className="mx-auto mt-6 max-w-xl text-[16px] leading-relaxed text-cream/70 lg:mx-0">
              <Editable
                k="cta.sub"
                value="Send us your dates and we'll come back with availability, photos and a total price — usually in under ten minutes. No deposit needed to get a quote."
                multiline
              />
            </p>

            <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row lg:justify-start">
              <WhatsAppButton
                size="lg"
                message={`Hi ${brand.name}! I'd like to book an apartment. My dates are: `}
              >
                Start a booking
              </WhatsAppButton>
              <a
                href="#apartments"
                className="inline-flex h-14 items-center justify-center rounded-sm border border-white/25 px-7 text-[15px] font-semibold text-cream transition-colors duration-300 hover:bg-white/10"
              >
                Browse apartments
              </a>
            </div>

            <div className="mt-12 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 border-t border-white/10 pt-8 lg:justify-start">
              {[
                { icon: <StarIcon className="h-4 w-4" />, text: `${brand.rating}/5 from ${brand.reviews} reviews`, k: "cta.trust.rating" },
                { icon: <ClockIcon className="h-4 w-4" />, text: "Replies in ~10 minutes", k: "cta.trust.reply" },
                { icon: <CheckIcon className="h-4 w-4" />, text: "Free cancellation up to 48h", k: "cta.trust.cancel" },
                { icon: <MailIcon className="h-4 w-4" />, text: brand.email, k: "cta.trust.email" },
              ].map((item) => (
                <span
                  key={item.text}
                  className="flex items-center gap-2 text-[13px] font-medium text-cream/60"
                >
                  <span className="text-bronze-soft">{item.icon}</span>
                  {item.text}
                </span>
              ))}
            </div>
          </div>

          {/* WhatsApp short-link card */}
          <div className="mx-auto w-full max-w-[320px]">
            <div className="rounded-lg bg-white p-6 text-center shadow-lift">
              <span className="mx-auto grid h-14 w-14 place-items-center rounded-sm bg-whatsapp text-white shadow-[0_10px_24px_-8px_rgba(37,211,102,0.7)]">
                <WhatsAppIcon className="h-7 w-7" />
              </span>
              <p className="mt-5 text-[16px] font-bold text-ink">
                Book on WhatsApp
              </p>
              <p className="mt-1.5 text-[13px] leading-relaxed text-ink-soft">
                Tap our short link to open a chat with Femi on{" "}
                <Editable k="brand.whatsappDisplay" value={brand.whatsappDisplay} />. No
                number to type — just tap and send.
              </p>
              <a
                href={brand.whatsappShortLink}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-5 block rounded-sm bg-shell px-4 py-3.5 font-display text-[20px] font-semibold tracking-[-0.01em] text-moss ring-1 ring-line transition-all duration-300 hover:bg-whatsapp/10 hover:text-whatsapp-dark hover:ring-whatsapp/40"
              >
                wa.link/hc0a3b
              </a>
              <p className="mt-3 text-[12px] text-ink-soft/80">
                Opens WhatsApp with our welcome message ready.
              </p>
            </div>
            <p className="mt-3.5 text-center text-[12px] text-cream/50">
              Save it or share it with anyone planning a trip.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  const { brand, wa } = useContent();
  return (
    <footer className="border-t border-line bg-cream">
      <div className="mx-auto max-w-[1240px] px-5 py-14 sm:px-8">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-sm bg-moss text-cream">
                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round">
                  <path d="M3 10.5 12 4l9 6.5" />
                  <path d="M5.5 9.8V20h13V9.8" />
                  <path d="M10 20v-5h4v5" />
                </svg>
              </span>
              <span className="font-display text-[19px] font-semibold tracking-[-0.02em]">
                {brand.name}
              </span>
            </div>
            <p className="mt-4 max-w-xs text-[14px] leading-relaxed text-ink-soft">
              <Editable
                k="footer.tagline"
                value={`${brand.tagline} in ${brand.city}. Furnished, powered and ready — booked entirely over WhatsApp.`}
                multiline
              />
            </p>
            <div className="mt-6">
              <WhatsAppButton
                variant="ghost"
                message={`Hi ${brand.name}! I'd like to enquire about a stay.`}
              >
                Chat with us
              </WhatsAppButton>
            </div>
          </div>

          <div>
            <h4 className="text-[13px] font-semibold tracking-[0.14em] text-ink uppercase">
              Explore
            </h4>
            <ul className="mt-4 space-y-3 text-[14px] text-ink-soft">
              {[
                ["Apartments", "#apartments"],
                ["Amenities", "#amenities"],
                ["How it works", "#how-it-works"],
                ["Reviews", "#reviews"],
                ["FAQ", "#faq"],
              ].map(([label, href]) => (
                <li key={label}>
                  <a href={href} className="transition-colors hover:text-ink">
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[13px] font-semibold tracking-[0.14em] text-ink uppercase">
              Areas
            </h4>
            <ul className="mt-4 space-y-3 text-[14px] text-ink-soft">
              {LOCATIONS.map((l) => (
                <li key={l.name}>
                  <a
                    href={wa(
                      `Hi ${brand.name}! Do you have availability in ${l.name}?`,
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="transition-colors hover:text-ink"
                  >
                    Shortlets in {l.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[13px] font-semibold tracking-[0.14em] text-ink uppercase">
              Contact
            </h4>
            <ul className="mt-4 space-y-3.5 text-[14px] text-ink-soft">
              <li className="flex items-start gap-2.5">
                <span className="mt-0.5 text-moss">
                  <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
                    <path d="M12 3C7.03 3 3 7.03 3 12c0 1.77.47 3.43 1.28 4.87L3 21l4.28-1.24A8.94 8.94 0 0 0 12 21c4.97 0 9-4.03 9-9s-4.03-9-9-9Z" />
                  </svg>
                </span>
                <a
                  href={wa(`Hi ${brand.name}! I'd like to make an enquiry.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-semibold text-ink transition-colors hover:text-moss"
                >
                  <Editable k="brand.whatsappDisplay" value={brand.whatsappDisplay} />
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="mt-0.5 text-moss">
                  <MailIcon className="h-4 w-4" />
                </span>
                <a href={`mailto:${brand.email}`} className="transition-colors hover:text-ink">
                  <Editable k="brand.email" value={brand.email} />
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="mt-0.5 text-moss">
                  <PinIcon className="h-4 w-4" />
                </span>
                <Editable k="brand.address" value={brand.address} multiline />
              </li>
              <li className="flex items-start gap-2.5">
                <span className="mt-0.5 text-moss">
                  <ClockIcon className="h-4 w-4" />
                </span>
                <Editable k="brand.hours" value={brand.hours} multiline />
              </li>
            </ul>

            <a
              href={brand.whatsappShortLink}
              target="_blank"
              rel="noopener noreferrer"
              className="group mt-6 flex items-center gap-3.5 rounded-sm border border-line bg-white p-3.5 transition-all duration-300 hover:border-whatsapp/50 hover:shadow-soft"
            >
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-whatsapp/15 text-whatsapp-dark">
                <WhatsAppIcon className="h-6 w-6" />
              </span>
              <span>
                <span className="block text-[13.5px] font-bold text-ink">
                  WhatsApp short link
                </span>
                <span className="mt-0.5 block font-display text-[15px] font-semibold text-moss transition-colors group-hover:text-whatsapp-dark">
                  wa.link/hc0a3b
                </span>
              </span>
            </a>

            <a
              href={brand.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-5 inline-flex items-center gap-2 rounded-sm border border-line bg-white px-4 py-2 text-[13px] font-semibold text-ink transition-colors hover:border-ink/25"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round">
                <rect x="3" y="3" width="18" height="18" rx="5" />
                <circle cx="12" cy="12" r="4" />
                <circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none" />
              </svg>
              <Editable k="brand.instagram" value={brand.instagram.replace("https://instagram.com/", "@")} />
            </a>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-line pt-7 sm:flex-row">
          <p className="text-[12.5px] text-ink-soft/80">
            © {new Date().getFullYear()} {brand.name}. All rights reserved.
          </p>
          <p className="text-[12.5px] text-ink-soft/80">
            Shortlets &amp; serviced apartments · {brand.city}
          </p>
        </div>
      </div>
    </footer>
  );
}
