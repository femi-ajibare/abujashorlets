import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Client-side image store for the property carousels.
 *
 * Uploaded photos are downscaled in the browser and kept in IndexedDB, so a
 * host can swap the stock photography for their own real files without any
 * backend. Use `exportManifest()` to download everything and bake it into
 * `src/data.ts` for the production build.
 */

const DB_NAME = "abuja-shortlets-images";
const DB_VERSION = 1;
const STORE = "overrides";
const KEY = "map";

export type ImageMap = Record<string, string[]>;

/* ----------------------------- IndexedDB ----------------------------- */

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB unavailable"));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function readMap(): Promise<ImageMap> {
  try {
    const db = await openDb();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(KEY);
      req.onsuccess = () => resolve((req.result as ImageMap) ?? {});
      req.onerror = () => reject(req.error);
    });
  } catch {
    return {};
  }
}

async function writeMap(map: ImageMap) {
  const db = await openDb();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(map, KEY);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function clearMap() {
  const db = await openDb();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(KEY);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

/* ------------------------- File → data URL --------------------------- */

const MAX_DIM = 1600;
const QUALITY = 0.82;

/** Reads an image file and returns a downscaled JPEG data URL. */
export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("Please choose an image file (JPG, PNG or WebP)."));
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read that file."));
    reader.onload = () => {
      const src = reader.result as string;
      const image = new Image();
      let settled = false;

      // Never hang: if the browser can't decode it in time, keep the original.
      const timer = window.setTimeout(() => {
        if (!settled) {
          settled = true;
          resolve(src);
        }
      }, 8000);

      image.onerror = () => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timer);
        reject(new Error("That file is not a valid image."));
      };
      image.onload = () => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timer);

        const scale = Math.min(1, MAX_DIM / Math.max(image.width, image.height));
        const w = Math.max(1, Math.round(image.width * scale));
        const h = Math.max(1, Math.round(image.height * scale));
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(src);
          return;
        }
        ctx.drawImage(image, 0, 0, w, h);
        try {
          resolve(canvas.toDataURL("image/jpeg", QUALITY));
        } catch {
          resolve(src);
        }
      };
      image.src = src;
    };
    reader.readAsDataURL(file);
  });
}

/* ------------------------------ Hook -------------------------------- */

export function useImageStore() {
  const [map, setMap] = useState<ImageMap>({});
  const [ready, setReady] = useState(false);
  const saveTimer = useRef<number | undefined>(undefined);

  useEffect(() => {
    let alive = true;
    readMap().then((stored) => {
      if (!alive) return;
      setMap(stored);
      setReady(true);
    });
    return () => {
      alive = false;
    };
  }, []);

  const commit = useCallback((next: ImageMap) => {
    setMap(next);
    window.clearTimeout(saveTimer.current);
    saveTimer.current = window.setTimeout(() => {
      writeMap(next).catch(() => {
        /* quota or private-mode failure — the UI still reflects the change */
      });
    }, 250);
  }, []);

  const replaceImage = useCallback(
    (id: string, index: number, dataUrl: string) => {
      setMap((prev) => {
        const list = [...(prev[id] ?? [])];
        while (list.length <= index) list.push("");
        list[index] = dataUrl;
        const next = { ...prev, [id]: list };
        commit(next);
        return next;
      });
    },
    [commit],
  );

  const addImage = useCallback(
    (id: string, dataUrl: string) => {
      setMap((prev) => {
        const next = { ...prev, [id]: [...(prev[id] ?? []), dataUrl] };
        commit(next);
        return next;
      });
    },
    [commit],
  );

  const removeImage = useCallback(
    (id: string, index: number) => {
      setMap((prev) => {
        const list = [...(prev[id] ?? [])];
        if (list.length <= 1) return prev;
        list.splice(index, 1);
        const next = { ...prev, [id]: list };
        commit(next);
        return next;
      });
    },
    [commit],
  );

  const resetProperty = useCallback(
    (id: string) => {
      setMap((prev) => {
        if (!(id in prev)) return prev;
        const next = { ...prev };
        delete next[id];
        commit(next);
        return next;
      });
    },
    [commit],
  );

  const resetAll = useCallback(() => {
    setMap({});
    clearMap().catch(() => {});
  }, []);

  /** Resolves the live photo list for a property (uploads win over stock). */
  const imagesFor = useCallback(
    (id: string, fallback: string[]) => map[id] ?? fallback,
    [map],
  );

  const editedCount = Object.keys(map).length;
  const uploadedCount = Object.values(map).reduce((n, l) => n + l.length, 0);

  return {
    ready,
    map,
    imagesFor,
    replaceImage,
    addImage,
    removeImage,
    resetProperty,
    resetAll,
    editedCount,
    uploadedCount,
  };
}

export type ImageStore = ReturnType<typeof useImageStore>;

/* ----------------------------- Export -------------------------------- */

/** Downloads every uploaded photo as a JSON manifest for the build. */
export function exportManifest(map: ImageMap) {
  const payload = {
    note: "Baked-in image overrides for Abuja Shortlets. Keys are apartment ids.",
    generated: new Date().toISOString(),
    images: map,
  };
  const json = JSON.stringify(payload, null, 2);
  const blob = new Blob([json], { type: "application/json" });

  const a = document.createElement("a");
  a.download = "apartment-images.json";

  if (typeof URL.createObjectURL === "function") {
    const url = URL.createObjectURL(blob);
    a.href = url;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    return;
  }

  // Fallback for environments without object URLs.
  const reader = new FileReader();
  reader.onload = () => {
    a.href = reader.result as string;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };
  reader.readAsDataURL(blob);
}
