import {
  createContext,
  createElement,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { BRAND } from "./config";
import { cn } from "./utils/cn";

/**
 * Site-wide inline CMS.
 *
 * Every string on the page is addressable by a stable key. In edit mode those
 * strings become editable in place; changes are stored in localStorage and can
 * be exported as JSON to bake into `src/config.ts` / `src/data.ts` for the
 * production build.
 */

const STORAGE_KEY = "abuja-shortlets-content-v1";

export type Overrides = Record<string, string>;

/* ------------------------------- storage ------------------------------- */

function load(): Overrides {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as Overrides) : {};
  } catch {
    return {};
  }
}

function save(map: Overrides) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(map));
  } catch {
    /* private mode / quota — the UI still reflects the change */
  }
}

/* ------------------------------ context -------------------------------- */

type Ctx = {
  editing: boolean;
  setEditing: (v: boolean) => void;
  overrides: Overrides;
  /** Resolve a string override, falling back to the baked-in value. */
  t: (key: string, fallback: string) => string;
  /** Resolve a numeric override. */
  n: (key: string, fallback: number) => number;
  set: (key: string, value: string) => void;
  unset: (key: string) => void;
  resetAll: () => void;
  /** BRAND merged with any brand.* overrides. */
  brand: typeof BRAND;
  /** Build a wa.me link using the (possibly overridden) number. */
  wa: (message: string) => string;
  dirtyCount: number;
};

const ContentContext = createContext<Ctx | null>(null);

export function ContentProvider({ children }: { children: ReactNode }) {
  const [overrides, setOverrides] = useState<Overrides>({});
  const [editing, setEditing] = useState(false);

  // Read stored overrides once on mount; until then the baked-in values show.
  useEffect(() => {
    setOverrides(load());
  }, []);

  const t = useCallback(
    (key: string, fallback: string) => overrides[key] ?? fallback,
    [overrides],
  );

  const n = useCallback(
    (key: string, fallback: number) => {
      const raw = overrides[key];
      if (raw == null) return fallback;
      const parsed = Number(String(raw).replace(/[^\d.-]/g, ""));
      return Number.isFinite(parsed) ? parsed : fallback;
    },
    [overrides],
  );

  const set = useCallback(
    (key: string, value: string) => {
      setOverrides((prev) => {
        const next = { ...prev, [key]: value };
        save(next);
        return next;
      });
    },
    [],
  );

  const unset = useCallback(
    (key: string) => {
      setOverrides((prev) => {
        if (!(key in prev)) return prev;
        const next = { ...prev };
        delete next[key];
        save(next);
        return next;
      });
    },
    [],
  );

  const resetAll = useCallback(() => {
    setOverrides({});
    save({});
  }, []);

  const brand = useMemo(() => {
    const b = { ...BRAND };
    (Object.keys(BRAND) as (keyof typeof BRAND)[]).forEach((k) => {
      const v = overrides[`brand.${k}`];
      if (v == null) return;
      if (typeof BRAND[k] === "number") {
        const parsed = Number(v);
        if (Number.isFinite(parsed)) (b[k] as number) = parsed;
      } else {
        (b[k] as string) = v;
      }
    });
    return b;
  }, [overrides]);

  const wa = useCallback(
    (message: string) =>
      `https://wa.me/${brand.whatsappNumber}?text=${encodeURIComponent(message)}`,
    [brand.whatsappNumber],
  );

  const dirtyCount = Object.keys(overrides).length;

  const value: Ctx = {
    editing,
    setEditing,
    overrides,
    t,
    n,
    set,
    unset,
    resetAll,
    brand,
    wa,
    dirtyCount,
  };

  // Always provide context — even before localStorage is read — so the first
  // render (and SSR/hydration) never sees a missing provider.
  return <ContentContext.Provider value={value}>{children}</ContentContext.Provider>;
}

export function useContent() {
  const ctx = useContext(ContentContext);
  if (!ctx) throw new Error("useContent must be used inside <ContentProvider>");
  return ctx;
}

/* ---------------------------- Editable text ---------------------------- */

type EditableProps = {
  /** Stable override key. */
  k: string;
  /** Baked-in value used when there is no override. */
  value: string;
  as?: "span" | "p" | "h1" | "h2" | "h3" | "h4" | "li" | "a" | "div" | "strong";
  className?: string;
  multiline?: boolean;
  title?: string;
};

/**
 * Renders plain text normally; in edit mode it becomes a contenteditable
 * field with a dashed bronze outline.
 */
export function Editable({
  k,
  value,
  as: Tag = "span",
  className,
  multiline,
  title,
}: EditableProps) {
  const { editing, t, set } = useContent();
  const ref = useRef<HTMLElement | null>(null);
  const current = t(k, value);

  // Keep the DOM in sync without React fighting contenteditable.
  useEffect(() => {
    if (ref.current && ref.current.textContent !== current) {
      ref.current.textContent = current;
    }
  }, [current, editing]);

  if (!editing) {
    return <Tag className={className}>{current}</Tag>;
  }

  return createElement(Tag, {
    ref,
    className: cn(
      className,
      "cursor-text rounded-sm outline-1 outline-dashed outline-bronze/60 transition-colors hover:bg-bronze/5 focus:bg-bronze/10 focus:outline-solid",
      multiline && "block whitespace-pre-wrap",
    ),
    contentEditable: true,
    suppressContentEditableWarning: true,
    spellCheck: false,
    title: title ?? "Click to edit",
    role: "textbox",
    tabIndex: 0,
    onBlur: (e: React.FocusEvent<HTMLElement>) => {
      const next = e.currentTarget.textContent ?? "";
      if (next !== value) set(k, next);
    },
    onKeyDown: (e: React.KeyboardEvent<HTMLElement>) => {
      if (!multiline && e.key === "Enter") {
        e.preventDefault();
        e.currentTarget.blur();
      }
    },
  });
}

/* --------------------------- Editable number --------------------------- */

type EditableNumberProps = {
  k: string;
  value: number;
  /** Renders the resolved number in view mode. */
  format?: (n: number) => string;
  className?: string;
  title?: string;
};

export function EditableNumber({
  k,
  value,
  format,
  className,
  title,
}: EditableNumberProps) {
  const { editing, n, set } = useContent();
  const resolved = n(k, value);

  if (!editing) {
    return <span className={className}>{format ? format(resolved) : resolved}</span>;
  }

  return (
    <input
      type="number"
      value={resolved}
      title={title ?? "Click to edit"}
      onChange={(e) => set(k, e.target.value)}
      onClick={(e) => e.stopPropagation()}
      className={cn(
        "w-28 cursor-text rounded-sm border border-bronze/50 bg-white px-2 py-1 text-[15px] font-bold text-ink outline-none focus:border-bronze",
        className,
      )}
    />
  );
}
