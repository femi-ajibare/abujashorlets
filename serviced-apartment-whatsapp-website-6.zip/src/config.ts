/**
 * Central place to wire the site to your business.
 * Change the phone number / handle here and every WhatsApp button updates.
 */

export const BRAND = {
  name: "Abuja Shortlets",
  tagline: "Serviced Apartments & Short Stays",
  city: "Abuja, Nigeria",
  /** WhatsApp number in international format, digits only. */
  whatsappNumber: "2348132714544",
  whatsappDisplay: "+234 813 271 4544",
  /** Short WhatsApp link (wa.link) — same number, handy for sharing & print. */
  whatsappShortLink: "https://wa.link/hc0a3b",
  email: "hello@abujashortlets.com",
  address: "24 Adetokunbo Ademola Crescent, Wuse II, Abuja",
  hours: "Concierge replies 7am – 11pm, every day",
  instagram: "https://instagram.com/abujashortlets",
  rating: 4.9,
  reviews: 312,
};

/** Builds a wa.me deep link with a pre-filled message. */
export function waLink(message: string, number: string = BRAND.whatsappNumber) {
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}

export const CURRENCY = "₦";

export function formatNaira(amount: number) {
  return CURRENCY + amount.toLocaleString("en-NG");
}
