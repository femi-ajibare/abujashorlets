export type Apartment = {
  id: string;
  /** Long, descriptive, SEO-style title — the luxuryshortlets.com convention. */
  name: string;
  /** Short label used for chips / filters. */
  short: string;
  area: string;
  price: number;
  beds: number;
  baths: number;
  guests: number;
  /** Multiple photos so each card has a working carousel. */
  images: string[];
  featured?: boolean;
  verified: "Vetted & verified" | "verified";
  amenities: string[];
  blurb: string;
};

const img = (id: number, w = 900, h = 700) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

export const APARTMENTS: Apartment[] = [
  /* ---------------------------- Katampe Extension --------------------------- */
  {
    id: "katampe-creme",
    name: "Crème de la Crème 1 Bedroom Apartment with 2 Balconies, Swimming Pool, Bar Area and Rooftop Terrace located in Katampe Extension",
    short: "Crème de la Crème",
    area: "Katampe Extension",
    price: 170000,
    beds: 1,
    baths: 1,
    guests: 2,
    images: [img(8135496), img(8134808), img(7166942)],
    featured: true,
    verified: "Vetted & verified",
    amenities: ["Swimming pool", "Rooftop terrace", "Bar area", "2 balconies"],
    blurb:
      "A standout 1 bedroom apartment in Katampe Extension with two balconies, a shared swimming pool, a rooftop terrace and a bar area.",
  },
  {
    id: "katampe-pool",
    name: "2 Bedroom in Katampe with Swimming Pool and Balcony",
    short: "Katampe 2 Bedroom",
    area: "Katampe Extension",
    price: 180000,
    beds: 2,
    baths: 2,
    guests: 4,
    images: [img(9494898), img(6585757), img(7534280)],
    featured: true,
    verified: "Vetted & verified",
    amenities: ["Swimming pool", "Balcony", "24/7 power", "Fast wifi"],
    blurb:
      "A comfortable 2 bedroom apartment in Katampe with a swimming pool and balcony. Furnished to a high standard with reliable power and internet.",
  },
  {
    id: "katampe-5bed",
    name: "Automated 5-Bedroom Duplex with a Swimming Pool, Snooker Board, Table Tennis Board, 24/7 Electricity, Super-fast Starlink Internet, and a PS5 Game Console",
    short: "5 Bedroom Duplex",
    area: "Katampe Extension",
    price: 430000,
    beds: 5,
    baths: 5,
    guests: 10,
    images: [img(6920439), img(7745929), img(27945011)],
    featured: true,
    verified: "verified",
    amenities: ["Swimming pool", "Snooker", "Table tennis", "Starlink", "PS5"],
    blurb:
      "An automated 5-bedroom duplex with a swimming pool, snooker and table tennis boards, 24/7 electricity, Starlink internet and a PS5 console.",
  },

  /* -------------------------------- Wuse 2 --------------------------------- */
  {
    id: "wuse2-penthouse",
    name: "Highly Secured Premium and Spacious 3 Bedroom Penthouse Apartment with Snooker Table, Swimming Pool, Private Balcony and Gym in Wuse 2",
    short: "Wuse 2 Penthouse",
    area: "Wuse 2",
    price: 270000,
    beds: 3,
    baths: 3,
    guests: 4,
    images: [img(7546314), img(7174113), img(30386965)],
    featured: true,
    verified: "Vetted & verified",
    amenities: ["Swimming pool", "Snooker table", "Gym", "Private balcony"],
    blurb:
      "A spacious, highly secured penthouse in Wuse 2 with a snooker table, swimming pool, private balcony and gym. Ideal for guests who want space.",
  },
  {
    id: "wuse2-studio",
    name: "Classic and Spacious Studio Shortlet Apartment in Wuse 2",
    short: "Wuse 2 Studio",
    area: "Wuse 2",
    price: 110000,
    beds: 1,
    baths: 1,
    guests: 2,
    images: [img(30554297), img(8089172), img(7018399)],
    featured: true,
    verified: "Vetted & verified",
    amenities: ["Bright & spacious", "Fast wifi", "Netflix ready", "24/7 power"],
    blurb:
      "A classic and spacious studio shortlet in Wuse 2. Bright, well-designed and great value for solo travellers and work trips.",
  },
  {
    id: "wuse2-3bed",
    name: "Unique Designed and Spacious Brand New Luxury 3 Bedroom Apartment · High Brow Area",
    short: "Wuse 2 3 Bedroom",
    area: "Wuse 2",
    price: 250000,
    beds: 3,
    baths: 3,
    guests: 6,
    images: [img(8135503), img(8082217), img(6782283)],
    featured: true,
    verified: "Vetted & verified",
    amenities: ["Brand new", "Unique design", "High security", "24/7 power"],
    blurb:
      "A brand new, tastefully designed 3 bedroom apartment in a high brow area of Wuse 2. Spacious, secure and finished to a premium standard.",
  },

  /* -------------------------------- Asokoro -------------------------------- */
  {
    id: "asokoro-rainfall",
    name: "1 Bed Shortlet Asokoro · Rainfall Shower",
    short: "Asokoro 1 Bed",
    area: "Asokoro",
    price: 190000,
    beds: 1,
    baths: 1,
    guests: 2,
    images: [img(8134808), img(6585757), img(6284230)],
    featured: true,
    verified: "Vetted & verified",
    amenities: ["Rainfall shower", "Full kitchen", "24/7 power", "Netflix ready"],
    blurb:
      "A 1 bedroom luxury shortlet in Asokoro with a full kitchen, dining area and rainfall shower. 24/7 power and security, fast wifi.",
  },
  {
    id: "asokoro-2bed",
    name: "Exquisitely Finished 2 Bedroom Apartment with Open Plan Lounge, Fitted Kitchen and 24/7 Power in Asokoro",
    short: "Asokoro 2 Bedroom",
    area: "Asokoro",
    price: 260000,
    beds: 2,
    baths: 2,
    guests: 4,
    images: [img(8141959), img(6394607), img(19827230)],
    verified: "Vetted & verified",
    amenities: ["Open plan lounge", "Fitted kitchen", "24/7 power", "Fast wifi"],
    blurb:
      "An exquisitely finished 2 bedroom apartment in Asokoro with an open-plan lounge, fitted kitchen and reliable power. A calm, leafy address.",
  },
  {
    id: "asokoro-4bed",
    name: "Fully Detached 4 Bedroom Duplex with Walled Compound, Ample Parking, BQ and Boys Quarters in Asokoro",
    short: "Asokoro 4 Bedroom Duplex",
    area: "Asokoro",
    price: 480000,
    beds: 4,
    baths: 4,
    guests: 8,
    images: [img(7167073), img(8082235), img(6076850)],
    verified: "verified",
    amenities: ["Fully detached", "Ample parking", "Boys quarters", "Walled compound"],
    blurb:
      "A fully detached 4 bedroom duplex in Asokoro with a walled compound, ample parking and a boys' quarters. Perfect for families and executives.",
  },

  /* -------------------------------- Maitama -------------------------------- */
  {
    id: "maitama-3bed",
    name: "Exquisite 3 Bedroom Highrise Apartment with Swimming Pool, Balcony, Bathtub & Private Chef / Chauffeur on Request",
    short: "Maitama Highrise",
    area: "Maitama",
    price: 550000,
    beds: 3,
    baths: 3,
    guests: 6,
    images: [img(8135492), img(8134808), img(7046002)],
    featured: true,
    verified: "verified",
    amenities: ["Swimming pool", "Bathtub", "Balcony", "Private chef"],
    blurb:
      "Our flagship highrise apartment with a swimming pool, bathtub, balcony and private chef on request. The most premium address in our collection.",
  },
  {
    id: "maitama-2bed",
    name: "Serviced 2 Bedroom Apartment with Panoramic City Views, Work Desk, Smart TV and Fibre WiFi in Maitama",
    short: "Maitama 2 Bedroom",
    area: "Maitama",
    price: 320000,
    beds: 2,
    baths: 2,
    guests: 4,
    images: [img(7722168), img(28054852), img(7166942)],
    verified: "Vetted & verified",
    amenities: ["City views", "Work desk", "Smart TV", "Fibre wifi"],
    blurb:
      "A serviced 2 bedroom apartment in Maitama with panoramic city views, a proper work desk, smart TV and fibre wifi. Built for business travellers.",
  },
  {
    id: "maitama-studio",
    name: "Compact and Elegant Studio Apartment with Modern Finishes, Netflix Ready Smart TV and Self Check-in in Maitama",
    short: "Maitama Studio",
    area: "Maitama",
    price: 140000,
    beds: 1,
    baths: 1,
    guests: 2,
    images: [img(7546323), img(6434612), img(7534280)],
    verified: "Vetted & verified",
    amenities: ["Modern finishes", "Netflix ready", "Self check-in", "Fast wifi"],
    blurb:
      "A compact and elegant studio in Maitama with modern finishes and self check-in. Great value in one of Abuja's most sought-after districts.",
  },

  /* -------------------------------- Mabushi -------------------------------- */
  {
    id: "mabushi-duplex",
    name: "Affordable Newly Renovated and Luxurious 3 Bedroom Duplex with 2 Parlours and Snooker Table located in Mabushi after Mobil to the Left",
    short: "Mabushi Duplex",
    area: "Mabushi",
    price: 160000,
    beds: 3,
    baths: 3,
    guests: 6,
    images: [img(7174113), img(8135503), img(27945011)],
    featured: true,
    verified: "Vetted & verified",
    amenities: ["Snooker table", "2 parlours", "Newly renovated", "24/7 power"],
    blurb:
      "A newly renovated 3 bedroom duplex in Mabushi with two parlours and a snooker table. Excellent value for groups and families.",
  },
  {
    id: "mabushi-1bed",
    name: "Neat and Affordable 1 Bedroom Apartment with Fitted Kitchen, Washing Machine and Free Parking in Mabushi",
    short: "Mabushi 1 Bedroom",
    area: "Mabushi",
    price: 90000,
    beds: 1,
    baths: 1,
    guests: 2,
    images: [img(8089172), img(2736384), img(7018399)],
    verified: "Vetted & verified",
    amenities: ["Fitted kitchen", "Washing machine", "Free parking", "24/7 power"],
    blurb:
      "A neat and affordable 1 bedroom apartment in Mabushi with a fitted kitchen, washing machine and free parking. Our best-value option.",
  },
  {
    id: "mabushi-2bed",
    name: "Newly Built 2 Bedroom Apartment with Spacious Lounge, Guest Toilet and Easy Access to Abuja City Centre in Mabushi",
    short: "Mabushi 2 Bedroom",
    area: "Mabushi",
    price: 135000,
    beds: 2,
    baths: 2,
    guests: 4,
    images: [img(9494898), img(7745929), img(6284230)],
    verified: "Vetted & verified",
    amenities: ["Newly built", "Guest toilet", "City centre access", "Free parking"],
    blurb:
      "A newly built 2 bedroom apartment in Mabushi with a spacious lounge and guest toilet, and easy access to the Abuja city centre.",
  },

  /* --------------------------------- Jahi ---------------------------------- */
  {
    id: "jahi-3bed",
    name: "Tastefully Designed Brand New 3 Bedroom Apartment with Modern Interiors, Ample Parking and 24/7 Power in Jahi",
    short: "Jahi 3 Bedroom",
    area: "Jahi",
    price: 220000,
    beds: 3,
    baths: 3,
    guests: 6,
    images: [img(7722168), img(7546314), img(19827230)],
    verified: "Vetted & verified",
    amenities: ["Brand new", "Ample parking", "24/7 power", "Modern interiors"],
    blurb:
      "A brand new 3 bedroom apartment in Jahi with modern interiors, ample parking and reliable 24/7 power. A quiet, fast-growing neighbourhood.",
  },
  {
    id: "jahi-2bed",
    name: "Contemporary 2 Bedroom Apartment with Balcony, Fitted Kitchen and Estate Amenities including Gym and Pool in Jahi",
    short: "Jahi 2 Bedroom",
    area: "Jahi",
    price: 165000,
    beds: 2,
    baths: 2,
    guests: 4,
    images: [img(8135496), img(6585757), img(30386965)],
    verified: "Vetted & verified",
    amenities: ["Balcony", "Fitted kitchen", "Estate gym", "Estate pool"],
    blurb:
      "A contemporary 2 bedroom apartment in Jahi with a balcony, fitted kitchen and access to estate amenities including a gym and pool.",
  },
  {
    id: "jahi-studio",
    name: "Modern Self-Contained Studio with Workspace, Smart TV and 24/7 Power in a Serene Estate in Jahi",
    short: "Jahi Studio",
    area: "Jahi",
    price: 85000,
    beds: 1,
    baths: 1,
    guests: 2,
    images: [img(30554297), img(6434612), img(6076850)],
    verified: "Vetted & verified",
    amenities: ["Self-contained", "Workspace", "Smart TV", "Serene estate"],
    blurb:
      "A modern self-contained studio in Jahi with a dedicated workspace, smart TV and 24/7 power, set in a serene estate. Ideal for remote workers.",
  },

  /* ------------------------------ Gwarinpa -------------------------------- */
  {
    id: "vi-waterfront",
    name: "Spacious 3 Bedroom Apartment with Modern Interiors, Ample Parking and 24/7 Power in Gwarinpa Estate",
    short: "Gwarinpa 3 Bedroom",
    area: "Gwarinpa",
    price: 380000,
    beds: 3,
    baths: 3,
    guests: 6,
    images: [img(6920439), img(8135503), img(6782283)],
    featured: true,
    verified: "verified",
    amenities: ["Ample parking", "Modern interiors", "24/7 power", "Family friendly"],
    blurb:
      "A spacious 3 bedroom apartment in Gwarinpa Estate with modern interiors, ample parking and reliable 24/7 power. Ideal for families and longer stays.",
  },
  {
    id: "vi-2bed",
    name: "Premium Two Bedroom Apartment with a City View, Modern Interiors, Balconies & Private Chef / Chauffeur on Request in Gwarinpa",
    short: "Gwarinpa 2 Bedroom",
    area: "Gwarinpa",
    price: 350000,
    beds: 2,
    baths: 2,
    guests: 4,
    images: [img(8082217), img(6394607), img(7166942)],
    featured: true,
    verified: "verified",
    amenities: ["City view", "Modern interiors", "Balconies", "Private chef"],
    blurb:
      "A premium two bedroom apartment in Gwarinpa with city views, modern interiors and balconies. Private chef and chauffeur available on request.",
  },
  {
    id: "vi-studio",
    name: "Stylish Serviced Studio Apartment with Skyline Views, Fibre WiFi and Self Check-in in Gwarinpa",
    short: "Gwarinpa Studio",
    area: "Gwarinpa",
    price: 145000,
    beds: 1,
    baths: 1,
    guests: 2,
    images: [img(7546314), img(28054852), img(7534280)],
    verified: "Vetted & verified",
    amenities: ["Skyline views", "Fibre wifi", "Self check-in", "Smart TV"],
    blurb:
      "A stylish serviced studio in Gwarinpa with skyline views, fibre wifi and self check-in. Our Gwarinpa base for business and weekend trips.",
  },
];

export type Amenity = {
  title: string;
  description: string;
  icon: string;
};

export const AMENITIES: Amenity[] = [
  {
    title: "24/7 Power & Security",
    description:
      "Every apartment runs on full inverter backup with standby generators, inside gated estates with 24-hour patrols and CCTV.",
    icon: "bolt",
  },
  {
    title: "Fast WiFi & Smart TVs",
    description:
      "Fibre-speed internet and smart TVs in every unit — Netflix ready, built for streaming and remote work.",
    icon: "wifi",
  },
  {
    title: "Fully Equipped Kitchens",
    description:
      "Cooker, microwave, fridge, cookware and everything you need for a home-cooked meal during your stay.",
    icon: "kitchen",
  },
  {
    title: "Swimming Pools & Gyms",
    description:
      "Most of our properties include a swimming pool and a gym, plus extras like snooker, PS5 consoles and rooftop terraces.",
    icon: "sparkle",
  },
  {
    title: "Self Check-in, 24 Hours",
    description:
      "Smart door codes sent before you arrive. Land at 2am? Walk straight in — no front desk, no waiting.",
    icon: "key",
  },
  {
    title: "Chef & Chauffeur on Request",
    description:
      "Add a private chef or chauffeur to selected properties. Just ask when you message us on WhatsApp.",
    icon: "shield",
  },
];

export type Step = {
  title: string;
  description: string;
};

export const STEPS: Step[] = [
  {
    title: "Pick your apartment",
    description:
      "Browse by area, filter by size and guests, and note the one you love.",
  },
  {
    title: "Tap “Book on WhatsApp”",
    description:
      "One tap opens WhatsApp with your dates and details already written out. Send the message — that's it.",
  },
  {
    title: "Get confirmed in minutes",
    description:
      "Our concierge replies with availability, a quote and payment options. Then you receive your door code.",
  },
];

export type Testimonial = {
  name: string;
  role: string;
  quote: string;
  initials: string;
};

export const TESTIMONIALS: Testimonial[] = [
  {
    name: "Ada Obi",
    role: "Business traveller · Port Harcourt",
    initials: "AO",
    quote:
      "I booked the Wuse 2 penthouse for a six-night conference stay. The whole booking took two minutes on WhatsApp and the door code was waiting in my chat. Spotless apartment, real fibre WiFi — I ran three client calls without a glitch.",
  },
  {
    name: "Tunde Bakare",
    role: "Family holiday · Kano",
    initials: "TB",
    quote:
      "We needed somewhere for ten people at short notice. They sorted the 5-bedroom duplex in Katampe in under an hour, including airport pickup. The kids didn't want to leave the pool.",
  },
  {
    name: "Chiamaka Eze",
    role: "Remote worker · Enugu",
    initials: "CE",
    quote:
      "I work from shortlets three months a year. This is the first place where the power genuinely never dropped and the desk setup was actually usable. Already rebooked for next month.",
  },
];

export type Faq = { q: string; a: string };

export const FAQS: Faq[] = [
  {
    q: "How do I book an apartment?",
    a: "Every booking happens inside WhatsApp. Tap any “Book on WhatsApp” button and a message opens with your enquiry pre-written — just add your dates and hit send. No account, no forms.",
  },
  {
    q: "How quickly will someone reply?",
    a: "Our concierge team answers between 7am and 11pm daily, usually within 10 minutes. Messages sent overnight get a first reply before 8am.",
  },
  {
    q: "What are your check-in and check-out times?",
    a: "Standard check-in is from 2pm and check-out is by 11am, but because we use smart door codes we can flex both for early mornings and late flights at no extra cost when the calendar allows.",
  },
  {
    q: "Is there a minimum stay?",
    a: "Two nights for most apartments, and three nights over weekends and public holidays. Monthly rates are available on stays of 28 nights or more.",
  },
  {
    q: "How do I pay?",
    a: "Bank transfer, card or USSD — all confirmed in the same WhatsApp thread. We ask for 30% to hold your dates and the balance on arrival.",
  },
  {
    q: "Can I cancel or move my dates?",
    a: "Yes. Free cancellation up to 48 hours before check-in, and we'll happily move your dates once if your plans change. Just message us.",
  },
  {
    q: "Are the apartments serviced during my stay?",
    a: "Cleaning is scheduled around you. Most guests get a light clean every third day and fresh linen weekly — tell us your preference on WhatsApp and we'll set it up.",
  },
  {
    q: "What does “Vetted & verified” mean?",
    a: "It means we have personally inspected the apartment and confirmed the interior matches the photos exactly. Every property we list has been checked before it goes live.",
  },
];

export type Location = {
  name: string;
  count: string;
  blurb: string;
};

/** Ordered list of areas — drives the per-area property sections. */
export const AREAS = [
  "Katampe Extension",
  "Wuse 2",
  "Asokoro",
  "Maitama",
  "Mabushi",
  "Jahi",
  "Gwarinpa",
] as const;

export const LOCATIONS: Location[] = [
  {
    name: "Katampe Extension",
    count: "3 apartments",
    blurb: "Quiet, upscale and close to the city centre.",
  },
  {
    name: "Wuse 2",
    count: "3 apartments",
    blurb: "The commercial heart of Abuja, close to everything.",
  },
  {
    name: "Asokoro",
    count: "3 apartments",
    blurb: "Leafy, secure and minutes from the hills.",
  },
  {
    name: "Maitama",
    count: "3 apartments",
    blurb: "Embassies, fine dining and the city's best addresses.",
  },
  {
    name: "Mabushi",
    count: "3 apartments",
    blurb: "Great value with easy access across Abuja.",
  },
  {
    name: "Jahi",
    count: "3 apartments",
    blurb: "A modern, fast-growing suburb with new builds.",
  },
  {
    name: "Gwarinpa",
    count: "3 apartments",
    blurb: "Abuja's largest residential estate — wide roads and family friendly.",
  },
];

/** Group apartments by area, preserving the AREAS order. */
export function byArea() {
  return AREAS.map((area) => ({
    area,
    apartments: APARTMENTS.filter((a) => a.area === area),
  })).filter((g) => g.apartments.length > 0);
}

export const GALLERY = [
  { image: img(8134808, 700, 900), caption: "Hotel-grade beds, every night" },
  { image: img(8082197, 700, 900), caption: "Kitchens you can cook in" },
  { image: img(8135496, 700, 900), caption: "Living rooms made for lingering" },
];
